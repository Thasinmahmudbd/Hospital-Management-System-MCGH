

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Profile'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/doctor/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/patients/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> My Patients </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> My Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/operation/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> Operation Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> My Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/doctor/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/patients/')); ?>">My Patients</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/schedule/')); ?>">My Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/operation/schedule/')); ?>">Operation Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/log/')); ?>">My Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                    <div class="rounded_photo_width_is_to_rest">

                        <div class="content_container center_element">

                        <?php if(Session::get('DOCTORS_IMAGE')): ?>

                            <img class="round_image" src="<?php echo e(asset('storage/doctor_profile_pictures/'.Session::get('DOCTORS_IMAGE'))); ?>" alt="" width="100%">

                        <?php elseif(Session::get('DOCTORS_GENDER')=='male' || Session::get('DOCTORS_GENDER')=='Male'): ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-male.png')); ?>" alt="" width="100%">

                        <?php elseif(Session::get('DOCTORS_GENDER')=='female' || Session::get('DOCTORS_GENDER')=='Female'): ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-female.png')); ?>" alt="" width="100%">

                        <?php else: ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/Profile_avatar_placeholder_large.png')); ?>" alt="" width="100%">

                        <?php endif; ?>

                        </div>




                        <div class="span_hidden_bar">

                            <div class="info content_container_bg_less">

                                <p class="collected_info">Name</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('DOCTORS_NAME')); ?></p>

                                <p class="collected_info">Department</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('DOCTORS_DEPARTMENT')); ?></p>

                                <p class="collected_info">Specialty</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('DOCTORS_SPECIALTY')); ?></p>

                                <p class="collected_info"><b>My Wallet</b></p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><b><?php echo e(Session::get('DOCTORS_BALANCE')); ?> Tk</b></p>

                            </div>

                            <a class="purple_icon" href="<?php echo e(url('/doctor/edit_profile/')); ?>">
                                <i class="fas fa-user-edit log_out_btn purple_icon"></i>
                            </a>

                        </div>

                    </div>



                <!--Session message-->

                <?php if(session('msg')=='Profile updated successfully.'): ?>

                    <div class="content_container_bg_less_thin text_center success_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>



                    <div class="content_container title_bar_purple right_side_top">

                        <span></span>
                            
                        <p><b>My Schedule</b></p>

                        <span><a href="<?php echo e(url('/doctor/schedule/')); ?>"><i class="fas fa-calendar-plus log_out_btn"></i></a></span>
                
                    </div>





                    <table class="frame_table">
                    
                    <tr class="frame_header">

                        <th width="12.5%" class="frame_header_item">Shift</th>




                        <?php if(Session::get('DAY_TODAY')=='Sat'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Sat</th>

                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Sat</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Sun'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Sun</th>
                            
                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Sun</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Mon'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Mon</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Mon</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Tue'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Tue</th>
                            
                            <?php else: ?>
    
                                <th width="12.5%" class="frame_header_item">Tue</th>
    
                            <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Wed'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Wed</th>
                            
                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Wed</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Thu'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Thu</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Thu</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Fri'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Fri</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Fri</th>
    
                        <?php endif; ?>

                    </tr>










                    <?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">

                        <td class="frame_data" data-label="Shift"><?php echo e($time->F); ?> - <?php echo e($time->T); ?></td>




                        <?php if(Session::get('DAY_TODAY')=='Sat'): ?>

                            <td class="frame_data border_indicator_animation disable" data-label="Sat">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Sat">

                        <?php endif; ?>

                                <?php if($time->Sat=='A' || $time->Sat=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Sat=='N/A' || $time->Sat=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Sun'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Sun">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Sun">

                        <?php endif; ?>

                                <?php if($time->Sun=='A' || $time->Sun=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Sun=='N/A' || $time->Sun=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Mon'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Mon">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Mon">

                        <?php endif; ?>

                                <?php if($time->Mon=='A' || $time->Mon=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Mon=='N/A' || $time->Mon=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Tue'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Tue">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Tue">

                        <?php endif; ?>

                                <?php if($time->Tue=='A' || $time->Tue=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Tue=='N/A' || $time->Tue=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Wed'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Wed">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Wed">

                        <?php endif; ?>

                                <?php if($time->Wed=='A' || $time->Wed=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Wed=='N/A' || $time->Wed=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Thu'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Thu">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Thu">

                        <?php endif; ?>

                                <?php if($time->Thu=='A' || $time->Thu=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Thu=='N/A' || $time->Thu=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Fri'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Fri">

                        <?php else: ?>

                            <td class="frame_data disable" data-label="Fri">

                        <?php endif; ?>

                                <?php if($time->Fri=='A' || $time->Fri=='a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Fri=='N/A' || $time->Fri=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
















<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/doctor/home.blade.php ENDPATH**/ ?>