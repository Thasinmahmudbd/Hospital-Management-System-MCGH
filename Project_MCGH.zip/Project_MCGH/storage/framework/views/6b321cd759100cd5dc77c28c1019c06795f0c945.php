

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Reception (Appoint Time)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

    <li class="link_item">
        <a href="<?php echo e(url('/reception/doctor_selection')); ?>" class="link">
            <i class="link_icons fas fa-user-md"></i>
            <span class="link_name"> Reselect Doctor </span>
        </a>
    </li>

    <li class="link_item">
        <a href="<?php echo e(url('/reception/cancel_appointment')); ?>" class="link">
            <i class="link_icons far fa-window-close"></i>
            <span class="link_name"> Cancel Appointment </span>
        </a>
    </li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/doctor_selection')); ?>">Reselect Doctor</a>
    </div>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/cancel_appointment_from_time_selection/')); ?>">Cancel Appointment</a>
    </div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



        <!--Session message-->

        <?php if(session('msg')=='Please assign an appointment time.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

        <?php elseif(session('msg')=='Appointment Canceled.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

        <?php endif; ?>







        <!--time table-->

        <div class="content_container">

            <form action="<?php echo e(url('/reception/change_date')); ?>" method="post" class="doctor_form">
                <?php echo csrf_field(); ?>
                    
                <div class="patient_form_element_three_is_to_one">
                
                    <p><?php echo e(Session::get('D_NAME')); ?>'s schedule.

                    <input type="date" class="input" name="appoint_date" value="<?php echo e(Session::get('PATIENT_APPOINT_DATE')); ?>" required>
                    
                    is 

                    <?php if(Session::get('PATIENT_APPOINT_DAY')=='Sun'): ?>

                        Sunday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Mon'): ?>

                        Monday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Tue'): ?>

                        Tuesday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Wed'): ?>

                        Wednesday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Thu'): ?>

                        Thursday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Fri'): ?>

                        Friday.

                    <?php elseif(Session::get('PATIENT_APPOINT_DAY')=='Sat'): ?>

                        Saturday.

                    <?php endif; ?>

                    </p>

                    <input type="submit" class="btn form_btn patient_form_btn" name="change_date" value="Save Changes">

                </div>

            </form>
                    
        </div>














                <table class="frame_table">
                    
                    <tr class="frame_header">

                        <th width="12.5%" class="frame_header_item">Time</th>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Sat'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Sat</th>

                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Sat</th>

                        <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Sun'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Sun</th>
                            
                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Sun</th>

                        <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Mon'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Mon</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Mon</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Tue'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Tue</th>
                            
                            <?php else: ?>
    
                                <th width="12.5%" class="frame_header_item">Tue</th>
    
                            <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Wed'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Wed</th>
                            
                        <?php else: ?>

                            <th width="12.5%" class="frame_header_item">Wed</th>

                        <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Thu'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Thu</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Thu</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Fri'): ?>

                            <th width="12.5%" class="frame_header_item background_indicator_animation">Fri</th>
                            
                        <?php else: ?>
    
                            <th width="12.5%" class="frame_header_item">Fri</th>
    
                        <?php endif; ?>

                    </tr>











                    <?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">

                        <td class="frame_data" data-label="Time"><?php echo e($time->F); ?> - <?php echo e($time->T); ?></td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Sat'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Sat">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Sat">

                        <?php endif; ?>

                                <?php if($time->Sat=='A' || $time->Sat=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php elseif($time->Sat=='N/A' || $time->Sat=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Sun'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Sun">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Sun">

                        <?php endif; ?>

                                <?php if($time->Sun=='A' || $time->Sun=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php elseif($time->Sun=='N/A' || $time->Sun=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Mon'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Mon">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Mon">

                        <?php endif; ?>

                                <?php if($time->Mon=='A' || $time->Mon=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php elseif($time->Mon=='N/A' || $time->Mon=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Tue'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Tue">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Tue">

                        <?php endif; ?>

                                <?php if($time->Tue=='A' || $time->Tue=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php elseif($time->Tue=='N/A' || $time->Tue=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Wed'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Wed">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Wed">

                        <?php endif; ?>

                                <?php if($time->Wed=='A' || $time->Wed=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php elseif($time->Wed=='N/A' || $time->Wed=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Thu'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Thu">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Thu">

                        <?php endif; ?>

                                <?php if($time->Thu=='A' || $time->Thu=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php elseif($time->Thu=='N/A' || $time->Thu=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('PATIENT_APPOINT_DAY')=='Fri'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Fri">

                        <?php else: ?>

                            <td class="frame_data disable shade" data-label="Fri">

                        <?php endif; ?>

                                <?php if($time->Fri=='A' || $time->Fri=='a'): ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_green"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php elseif($time->Fri=='N/A' || $time->Fri=='n/a'): ?>
                                    <a href="" class="disable">
                                        <p class="table_basic_btn"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/reception/set_time/'.$time->AI_ID)); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>







                <div class="gap"></div>


                <!--Patient info tab-->

                <div class="patient_and_doctor_info_one_is_to_one">

                    <div class="content_container_bg_less">

                        <p class="section_title">Patient Info</p>

                        <div class="info">

                            <p class="collected_info">Patient's Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_NAME')); ?></p>

                            <p class="collected_info">Patient's Gender</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_GENDER')); ?></p>

                            <p class="collected_info">Cell Number</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_CELL')); ?></p>

                            <p class="collected_info">Patient ID</p>
                            <p>:</p>
                            <p class="collected_info">N/A</p>

                            <p class="collected_info">Patient NID</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_NID')); ?></p>

                            <p class="collected_info">NID Type</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_NID_TYPE')); ?></p>

                        </div>

                    </div>





                    <!-- Billing -->

                    <div class="content_container">

                        <form action="<?php echo e(url('/reception/patient_data_entry_for_doctor_appointment')); ?>" method="post" class="doctor_form">
                        <?php echo csrf_field(); ?>
                                    
                            <!--<div class="doctor_form_element">
                                <p class="collected_info">Fee</p>
                                <input type="tel" class="input collected_info" name="fee" required>
                                <p class="collected_info">TK</p>
                            </div>-->

                            <div class="disNone">
                                <p class="collected_info">Holder Estimated Bill</p>
                                <input type="tel" class="input_less collected_info" id="fee" value="<?php echo e(Session::get('BASIC_FEE')); ?>" readonly>
                            </div>
                            
                            <div class="doctor_form_element">
                                <p class="collected_info">Estimated Bill</p>
                                <input type="tel" class="input_less collected_info" name="paidAmount" id="estimate" readonly>
                            </div>
                            
                            <div class="doctor_form_element">
                                <p class="collected_info">Discount</p>
                                <input type="tel" class="input collected_info" name="discount" value="<?php echo e(Session::get('DISCOUNT')); ?>" id="disc" oninput="calcDisc()" required>
                                <p class="collected_info">%</p>
                            </div>

                            <div class="doctor_form_element">
                                <p class="collected_info">Payment</p>
                                <select name="payment_status" id="payment_status" class="input collected_info" required>
                                    <option value="Paid">Paid</option>
                                    <option value="Due">Due</option>
                                </select>
                            </div>

                            <div class="doctor_form_element">
                                <p class="collected_info">Received</p>
                                <input type="tel" class="input collected_info" name="received" oninput="calcAppointmentFee()" id="r2" value="0" required>
                            </div>

                            <div class="doctor_form_element">
                                <p class="collected_info">Change</p>
                                <input type="tel" class="input collected_info" name="change" id="c2" value="0" required>
                            </div>

                            <div class="doctor_form_element">
                                <span class="collected_info"></span>
                                <input type="submit" class="btn form_btn" name="enroll" value="Register">
                            </div>

                        </form>

                    </div>





                    <div class="content_container_bg_less">

                        <p class="section_title">Doctor Chosen</p>

                        <div class="info">

                            <p class="collected_info">Doctor's Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('D_NAME')); ?></p>

                            <p class="collected_info">Fee</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('BASIC_FEE')); ?></p>

                            <p class="collected_info">Date</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_APPOINT_DATE')); ?></p>

                            <p class="collected_info">Time</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_APPOINT_TIME')); ?></p>

                        </div>

                    </div>

                </div>









<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->


<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/appoint_time.blade.php ENDPATH**/ ?>