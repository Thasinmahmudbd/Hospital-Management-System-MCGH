<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <!--icons | font awesome-->
	<link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Basic/fontawesome.min.css')); ?>"/>
    
    <!--font | nunito-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200&display=swap" rel="stylesheet"> 

    <!--global design-->
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Global/global_design.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Global/form_design.css')); ?>">

    <!--basic design-->
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Basic/reception_design.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Basic/doctor_design.css')); ?>">

    <!--frame design-->
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/frame_design.css')); ?>">

    <!--responsive design-->
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Responsive/reception_res.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Responsive/doctor_res.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('UI_assets/Design/Responsive/frame_res.css')); ?>">

    <!--javascript-->
    <script src="<?php echo e(asset('UI_assets/Javascript/dropdown_menu.js')); ?>"></script>
    <script src="<?php echo e(asset('UI_assets/Javascript/imageViewer.js')); ?>"></script>
    <script src="<?php echo e(asset('UI_assets/Javascript/triggerClick.js')); ?>"></script>
    <script src="<?php echo e(asset('UI_assets/Javascript/calc.js')); ?>"></script>
    <script src="<?php echo e(asset('UI_assets/Javascript/autoFill.js')); ?>"></script>
	<script src="<?php echo e(asset('UI_assets/Javascript/fontawesome.min.js')); ?>"></script>
    
    <script type="text/javascript">
        function disableBack() { window.history.forward(); }
        setTimeout("disableBack()", 0);
        window.onunload = function () { null };

        window.onload=function(){
            calcDisc();
            calcAdmissionFee();
            calcAppointmentFee();
        }
    </script>


<!-----------------------charts---------------------->

    <?php $__env->startSection('charts'); ?>
    <?php echo $__env->yieldSection(); ?>

<!--------------------charts end---------------------->


    <title><?php echo $__env->yieldContent('page_title'); ?></title>



</head>


<body>

    <!--frame-->
    <div class="frame">

        <!--frame left side-->
        <div class="left_side">

            <div class="left_side_top">

                <p class="title">MCGH Portal</p>
                <div class="line"></div>
                <p class="user_name_id">
                    
                    <?php if(Session::get('REC_SESSION_ID')): ?>
                        <?php echo e(Session::get('R_NAME')); ?>

                    <?php elseif(Session::get('DOC_SESSION_ID')): ?>
                        <?php echo e(Session::get('DOCTORS_NAME')); ?>

                    <?php elseif(Session::get('ACC_SESSION_ID')): ?>
                        <?php echo e(Session::get('ACC_NAME')); ?>

                    <?php elseif(Session::get('OTO_SESSION_ID')): ?>
                        <?php echo e(Session::get('OTO_NAME')); ?>

                    <?php elseif(Session::get('NRS_SESSION_ID')): ?>
                        <?php echo e(Session::get('N_NAME')); ?>

                    <?php endif; ?>
                
                    <br>(
                    
                    <?php if(Session::get('REC_SESSION_ID')): ?>
                        <?php echo e(Session::get('REC_SESSION_ID')); ?>

                    <?php elseif(Session::get('DOC_SESSION_ID')): ?>
                        <?php echo e(Session::get('DOC_SESSION_ID')); ?>

                    <?php elseif(Session::get('ACC_SESSION_ID')): ?>
                        <?php echo e(Session::get('ACC_SESSION_ID')); ?>

                    <?php elseif(Session::get('OTO_SESSION_ID')): ?>
                        <?php echo e(Session::get('OTO_SESSION_ID')); ?>

                    <?php elseif(Session::get('NRS_SESSION_ID')): ?>
                        <?php echo e(Session::get('NRS_SESSION_ID')); ?>

                    <?php endif; ?>

                    )
                
                </p>

            </div>
            
            <ul class="list">

<!-----------------------link---------------------->

            <?php $__env->startSection('links'); ?>
            <?php echo $__env->yieldSection(); ?>

<!--------------------link end---------------------->

            </ul>

        </div>

        <!--frame right side-->
        <div class="right_side">

            <!--frame right side top-->
            <div class="right_side_top">

                <a href="javascript:void(0);" onclick="myFunction()">
                    <i class="fas fa-bars menu_btn"></i>
                </a>
                <p class="page_type"><?php echo $__env->yieldContent('page_type'); ?></p>
                <a href="<?php echo e(url('/logout')); ?>">
                    <i class="fas fa-power-off log_out_btn"></i>
                </a>

            </div>

            <!--frame right side mobile menu links-->
            <?php $__env->startSection('mobile_links'); ?>
            <?php echo $__env->yieldSection(); ?>

            <!--frame right side middle-->
            <div class="right_side_middle">

<!-----------------------content---------------------->


            <?php $__env->startSection('content'); ?>
            <?php echo $__env->yieldSection(); ?>

<!--------------------content end---------------------->

            </div>

        </div>

    </div>


</body>
</html><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/frame/frame.blade.php ENDPATH**/ ?>