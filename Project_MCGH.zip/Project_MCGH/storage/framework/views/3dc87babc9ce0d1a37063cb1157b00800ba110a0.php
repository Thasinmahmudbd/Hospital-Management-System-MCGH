

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Logs'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/doctor/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/patients/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> My Patients </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> My Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/operation/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> Operation Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> My Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/doctor/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/patients/')); ?>">My Patients</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/schedule/')); ?>">My Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/operation/schedule/')); ?>">Operation Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/log/')); ?>">My Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

    <div class="content_container_bg_less_thin">

        <span></span>
            
            <p><b>Search patients</b></p>

        <span></span>

    </div>





    <form action="<?php echo e(url('/doctor/search_based_on_date/')); ?>" method="post" class="span_hidden_bar content_container_bg_less_thin center_element">
    <?php echo csrf_field(); ?>

        <div class="patient_and_doctor_info_one_is_to_one">

            <div class="patient_form_element_one_is_to_three center_element content_container">
                <label class="center_element" for="search_from">From</label>
                <input class="input" type="date" name="search_from" required>  
            </div>

            <div class="patient_form_element_one_is_to_three center_element content_container">
                <label class="center_element" for="search_to">To</label>
                <input class="input" type="date" name="search_to" required>  
            </div>

        </div>

        <div>

            <button class="btn form_btn" type="submit" name="submit"> 
                <i class="fas fa-search log_out_btn"></i>
            </button>

        </div>

    </form>




    <div class="purple_line"></div>


    <div class="content_container_bg_less_thin">

        <span></span>
            
            <p><b>Logs <?php echo e(Session::get('LOG_LIMIT')); ?></b></p>

        <span></span>

    </div>





                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="20%" class="frame_header_item">Date</th>
                        <th width="30%" class="frame_header_item">P-ID</th>
                        <th width="30%" class="frame_header_item">Patient Name</th>
                        <th width="20%" class="frame_header_item">Gender</th>
                    </tr>

                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="Date"><?php echo e($list->Ap_Date); ?></td>
                        <td class="frame_data" data-label="P-ID"><?php echo e($list->P_ID); ?></td>
                        <td class="frame_data" data-label="Patient Name"><?php echo e($list->Patient_Name); ?></td>
                        <td class="frame_data" data-label="Gender"><?php echo e($list->Patient_Gender); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>







<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/doctor/logs.blade.php ENDPATH**/ ?>