

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','OT (List)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/ot/new/entry/all/data')); ?>" class="link">
        <i class="link_icons fas fa-th-list"></i>
        <span class="link_name"> Refresh List </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/doctor_selection')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Surgeon </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/show/anesthesiologist/list')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Anesthesiologist </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/show/nurse/list')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Nurse </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/assistant/data/collection')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Assistant </span>
    </a>
</li>

<li class="link_item">
    <a href="<?php echo e(url('/ot/new/entry/cancel')); ?>" class="link">
        <i class="link_icons far fa-window-close"></i>
        <span class="link_name"> Cancel Entry </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/ot/new/entry/all/data')); ?>">Refresh List</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/doctor_selection')); ?>">Pick Surgeon</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/show/anesthesiologist/list')); ?>">Pick Anesthesiologist</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/show/nurse/list')); ?>">Pick Nurse</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/assistant/data/collection')); ?>">Pick Assistant</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/new/entry/cancel')); ?>">Cancel Entry</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>






            <!--Patient info tab-->

            <div class="patient_and_doctor_info_one_is_to_one">

                <div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Patient Info</p>

                        <div class="info">

                            <p class="collected_info">Patient's ID</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('OT_NEW_ENTRY_P_ID')); ?></p>

                            <p class="collected_info">Operation Type</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('o_type')); ?></p>

                            <p class="collected_info">Operation Date</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('o_date')); ?></p>

                            <p class="collected_info">Operation Time</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('o_time')); ?></p>

                            <p class="collected_info">Operation Duration</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('o_duration')); ?></p>

                            <p class="collected_info">Anesthesia Type</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('a_type')); ?></p>

                        </div>

                    </div>

                </div>




                <div>

                    <!--consultant info-->

                    <div class="content_container_bg_less">

                        <p class="section_title">OT Charges</p>

                        <div class="info">

                            <p class="collected_info">OT Charge</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('ot_charge')); ?></p>

                            <p class="collected_info">OT Discount</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('ot_charge_discount')); ?></p>

                        </div>

                        <div class="gap"></div>

                        <p class="section_title">Other Charges</p>

                        <div class="info">

                            <p class="collected_info">Other</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('ot_other')); ?></p>

                            <p class="collected_info">Other Charges</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('ot_other_charge')); ?></p>

                        </div>

                    </div>

                </div>

            </div>








            <div class="purple_line"></div>
            <div class="gap"></div>






                <!--surgeon info-->

                    <div class="patient_form_element_one_is_to_100px">

                        <div class="content_container_bg_less">
        
                            <p><b>Surgeons:</b></p>

                        </div>

                        <div class="content_nav">
        
                            <a href="<?php echo e(url('/ot/doctor_selection')); ?>" class="content_nav_link purple">Add</a>

                        </div>

                    </div>


                <!--Session message-->

                <?php if(session('msg')=='Delete all Surgeon entry and try again.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php elseif(session('msg')=='Input at least 1 surgeon.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>



                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="57%" class="frame_header_item">Name</th>
                        <th width="15%" class="frame_header_item">Fees</th>
                        <th width="15%" class="frame_header_item">Discount</th>
                        <th width="8%" class="frame_header_item">Remove</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $chosen_surgeons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Name"><?php echo e($list->Surgeon_Name); ?></td>
                        <td class="frame_data" data-label="Fees"><?php echo e($list->Surgeon_Fee); ?></td>
                        <td class="frame_data" data-label="Discount"><?php echo e($list->Surgeon_Discount); ?></td>

                        <td class="frame_action" data-label="Action">
                            <a target="blank" href="<?php echo e(url('/remove/surgeon/'.$list->AI_ID)); ?>">
                                <i class="table_btn_red fas fa-times-circle"></i>
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <div class="gap"></div>








                <!--anesthesiologists: info-->

                    <div class="patient_form_element_one_is_to_100px">

                        <div class="content_container_bg_less">
        
                            <p><b>Anesthesiologists:</b></p>

                        </div>

                        <div class="content_nav">
        
                            <a href="<?php echo e(url('/ot/show/anesthesiologist/list')); ?>" class="content_nav_link purple">Add</a>

                        </div>

                    </div>


                <!--Session message-->

                <?php if(session('msg')=='Delete all Anesthesiologist entry and try again.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>


                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="57%" class="frame_header_item">Name</th>
                        <th width="15%" class="frame_header_item">Fees</th>
                        <th width="15%" class="frame_header_item">Discount</th>
                        <th width="8%" class="frame_header_item">Remove</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $chosen_anesthesiologist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Name"><?php echo e($list->Anesthesiologist_Name); ?></td>
                        <td class="frame_data" data-label="Fees"><?php echo e($list->Anesthesiologist_Fee); ?></td>
                        <td class="frame_data" data-label="Discount"><?php echo e($list->Anesthesiologist_Discount); ?></td>

                        <td class="frame_action" data-label="Action">
                            <a target="blank" href="<?php echo e(url('/remove/anesthesiologist/'.$list->AI_ID)); ?>">
                                <i class="table_btn_red fas fa-times-circle"></i>
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <div class="gap"></div>







                <!--nurses info-->

                    <div class="patient_form_element_one_is_to_100px">

                        <div class="content_container_bg_less">
        
                            <p><b>Nurses:</b></p>

                        </div>

                        <div class="content_nav">
        
                            <a href="<?php echo e(url('/ot/show/nurse/list')); ?>" class="content_nav_link purple">Add</a>

                        </div>

                    </div>



                <!--Session message-->

                <?php if(session('msg')=='Delete all Nurse entry and try again.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>



                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="72%" class="frame_header_item">Name</th>
                        <th width="15%" class="frame_header_item">Fees</th>
                        <th width="8%" class="frame_header_item">Remove</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $chosen_nurses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Name"><?php echo e($list->Nurse_Name); ?></td>
                        <td class="frame_data" data-label="Fees"><?php echo e($list->Nurse_Fee); ?></td>

                        <td class="frame_action" data-label="Action">
                            <a target="blank" href="<?php echo e(url('/remove/nurse/'.$list->AI_ID)); ?>">
                                <i class="table_btn_red fas fa-times-circle"></i>
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <div class="gap"></div>







                <!--assistants: info-->

                    <div class="patient_form_element_one_is_to_100px">

                        <div class="content_container_bg_less">
        
                            <p><b>Assistants:</b></p>

                        </div>

                        <div class="content_nav">
        
                            <a href="<?php echo e(url('/ot/assistant/data/collection')); ?>" class="content_nav_link purple">Add</a>

                        </div>

                    </div>



                <!--Session message-->

                <?php if(session('msg')=='Delete all Assistant entry and try again.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>




                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="72%" class="frame_header_item">Name</th>
                        <th width="15%" class="frame_header_item">Fees</th>
                        <th width="8%" class="frame_header_item">Remove</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $chosen_assistant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Name"><?php echo e($list->Assistant_Name); ?></td>
                        <td class="frame_data" data-label="Fees"><?php echo e($list->Assistant_Fee); ?></td>

                        <td class="frame_action" data-label="Action">
                            <a target="blank" href="<?php echo e(url('/remove/assistant/'.$list->AI_ID)); ?>">
                                <i class="table_btn_red fas fa-times-circle"></i>
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <div class="gap"></div>


                <form action="<?php echo e(url('/ot/entry/list/submit')); ?>" class="patient_info_form" method="post">
                <?php echo csrf_field(); ?>

                    <div class="patient_form_element">

                        <input type="submit" class="btn content_nav_link table_item_green"  value="Confirm all entry -- [CAUTION: This is final and can't be undone.]" name="Next">

                    </div>

                </form>



<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->





<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/ot/ot_entry_data_list.blade.php ENDPATH**/ ?>