

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Patients'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/doctor/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/patients/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> My Patients </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> My Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/operation/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> Operation Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> My Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/doctor/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/patients/')); ?>">My Patients</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/schedule/')); ?>">My Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/operation/schedule/')); ?>">Operation Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/log/')); ?>">My Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



                <p class="span_hidden_bar">

                    <b class="content_container_bg_less_thin">Search patient & add them as treated. Total appointments today :</b>

                    <span class="text_center table_item_orange content_container_bg_less_thin">

                        <?php echo e(Session::get('UNTREATED')); ?>


                    </span>

                </p>




                <!-- patient search -->
                <form action="<?php echo e(url('/doctor/search_patient/')); ?>" method="post" class="content_container patient_info_form">
                <?php echo csrf_field(); ?>

                    <div class="doctor_search_form_element">

                        <label for="p_id" class="collected_info vanish_label">Search Patient</label>

                        <div class="patient_and_doctor_info_one_is_to_one">

                            <input type="text" class="input" name="p_id" placeholder="Enter P_ID" required>
                            <input type="text" class="input" name="random_code" placeholder="Enter R-C" required>

                        </div>

                        <button type="submit" class="btn form_btn" name="search_patient">Find</button>
    
                    </div>

                </form>



                <!--Session message-->
                <?php if(session('msg')=='Sorry, but none fits your description.'): ?>

                    <div class="content_container_bg_less_thin text_center warning_msg"><?php echo e(session('msg')); ?></div> 

                <?php elseif(session('msg')=='Congratulation, list has been updated.'): ?>

                    <div class="content_container_bg_less_thin text_center success_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>
                


                <?php if(Session::get('PATIENT_SEARCH_RESULT')=='positive'): ?>

                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <form action="<?php echo e(url('/doctor/set_patient_as_treated/')); ?>" class="patient_and_doctor_info_one_is_to_one" method="post">
                    <?php echo csrf_field(); ?>

                        <div class="content_container_bg_less info">

                            <p class="collected_info">Patient Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e($list->Patient_Name); ?></p>

                            <p class="collected_info">Patient Gender</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e($list->Patient_Gender); ?></p>

                            <p class="collected_info">Appointment Date</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e($list->Ap_Date); ?></p>

                            <input type="hidden" value="<?php echo e($list->P_ID); ?>" name="p_id">

                        </div>

                        <div class="patient_form_element">

                            <button type="submit" class="btn content_container_bg_less form_btn" name="select_doctor">I, <?php echo e(Session::get('DOCTORS_NAME')); ?>,<br> have treated this person on <?php echo e(Session::get('DATE_TODAY')); ?>,<br> at <?php echo e(Session::get('CURRENT_TIME')); ?>.</button>

                        </div>

                    </form>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>


                <div class="purple_line"></div>

                <span class="gap"></span>






                <p class="span_hidden_bar">

                    <b class="content_container_bg_less_thin">Patients you've treated today :</b>

                    <span class="text_center table_item_orange content_container_bg_less_thin">

                        <?php echo e(Session::get('TREATED')); ?>


                    </span>

                </p>





                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="40%" class="frame_header_item">P-ID</th>
                        <th width="40%" class="frame_header_item">Patient Name</th>
                        <th width="20%" class="frame_header_item">Gender</th>
                    </tr>

                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="P-ID"><?php echo e($list->P_ID); ?></td>
                        <td class="frame_data" data-label="Patient Name"><?php echo e($list->Patient_Name); ?></td>
                        <td class="frame_data" data-label="Gender"><?php echo e($list->Patient_Gender); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>













<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/doctor/patient_list.blade.php ENDPATH**/ ?>