

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Operation Schedule'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/doctor/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/patients/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> My Patients </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> My Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/operation/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> Operation Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> My Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/doctor/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/patients/')); ?>">My Patients</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/schedule/')); ?>">My Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/operation/schedule/')); ?>">Operation Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/log/')); ?>">My Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>





                <!--Showing schedules-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>My Operation Schedules</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="20%" class="frame_header_item">P-ID</th>
                        <th width="20%" class="frame_header_item">Operation Type</th>
                        <th width="10%" class="frame_header_item">OT</th>
                        <th width="15%" class="frame_header_item">Date</th>
                        <th width="15%" class="frame_header_item">Time</th>
                        <th width="15%" class="frame_header_item">Est. Duration</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">

                        <td class="frame_data" data-label="S/N" width="5%"><?php echo $serial; $serial++; ?></td>

                        <td class="frame_data" data-label="P-ID" width="20%"><?php echo e($list->P_ID); ?></td>

                        <td class="frame_data" data-label="Operation Type" width="20%"><?php echo e($list->Operation_Type); ?></td>

                        <td class="frame_data" data-label="OT" width="10%"><?php echo e($list->OT_No); ?></td>

                        <td class="frame_data" data-label="Date" width="15%"><?php echo e($list->Operation_Date); ?></td>

                        <td class="frame_data" data-label="Time" width="15%"><?php echo e($list->Operation_Start_Time); ?></td>

                        <td class="frame_data" data-label="Est. Duration" width="15%"><?php echo e($list->Estimated_Duration); ?></td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>




<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/doctor/operation_schedule.blade.php ENDPATH**/ ?>