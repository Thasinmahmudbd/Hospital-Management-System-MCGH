

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Nurse (Others)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/nurse/home/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patient List </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/nurse/home/')); ?>">Patient List</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>







                    <div class="patient_form_element_one_is_to_one">

                        <div class="block">

                            <div class="content_container_bg_less">

                                <p class="section_title">Patient Info</p>

                                <div class="info">

                                    <p class="collected_info">Patients's Name</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('patient_name')); ?></p>

                                </div>

                            </div>

                            <div class="content_container_bg_less">

                                <p class="section_title">Bed Info</p>

                                <div class="info">

                                    <p class="collected_info">Bed No</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('bed_no')); ?></p>

                                    <p class="collected_info">Floor No</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('floor_no')); ?></p>

                                </div>

                            </div>

                            <div class="content_container_bg_less">

                                <p class="section_title">Service Info</p>

                                <div class="info">

                                    <p class="collected_info">Service</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('Service_Name')); ?></p>

                                    <p class="collected_info">Quantity</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('quantity')); ?></p>

                                    <p class="collected_info">Service Charge</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('Service_Charge')); ?></p>

                                </div>

                            </div>

                        </div>

                        <div class="block">

                            <div class="gap"></div>

                            <table class="frame_table">

                                <!--enter others-->
                                <form action="<?php echo e(url('/nurse/personal/selected')); ?>" class="content_container patient_info_form" method="post">
                                <?php echo csrf_field(); ?>

                                <?php if(Session::get('DMO')=='yes'): ?>

                                <tr class="frame_rows">

                                    <th width="20%" class="frame_header_item">Doctor</th>
                                    <td class="frame_data" data-label="Personal">
                                        <select name="dmo" id="dmo" class="input_less" required>
                                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($list->D_ID); ?>"><?php echo e($list->Dr_Name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>

                                </tr>

                                <?php endif; ?>

                                <?php if(Session::get('Nurse')=='yes'): ?>

                                <tr class="frame_rows">

                                    <th width="20%" class="frame_header_item">Nurse</th>    
                                    <td class="frame_data" data-label="Personal">
                                        <select name="nurse" id="nurse" class="input_less" required>
                                            <?php $__currentLoopData = $info2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($list->N_ID); ?>"><?php echo e($list->N_Name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>

                                </tr>

                                <?php endif; ?>

                                <?php if(Session::get('Assistant')=='yes'): ?>

                                <tr class="frame_rows">

                                    <th width="20%" class="frame_header_item">Assistant</th>    
                                    <td class="frame_data" data-label="Personal">
                                        <input type="text" class="input_less"  name="assistant_name" placeholder="Enter Name">
                                    </td>

                                </tr>

                                <?php endif; ?>

                                <tr class="frame_rows">

                                    <td class="frame_action table_item_dark_green" data-label="Action" colspan="2">
                                        <input type="submit" class="table_item_dark_green btn"  value="Done" name="next">
                                    </td>

                                </tr>

                                </form>

                            </table>

                        </div>

                    </div>










<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/nurse/select_personal.blade.php ENDPATH**/ ?>