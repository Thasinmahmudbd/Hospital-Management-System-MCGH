

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Profile'); ?>








<!--------------------charts----------------------->

<?php $__env->startSection('charts'); ?>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load("current", {packages:["corechart"]});
        google.charts.setOnLoadCallback(drawChart);
        function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Accounts', 'Taka'],
            ['Total Commission',     <?php echo e(Session::get('COMMISSION')); ?>],
            ['Total Vat',      <?php echo e(Session::get('VAT')); ?>],
            ['Doctor Salary',  <?php echo e(Session::get('REST')); ?>]
            
        ]);

        var options = {
            title: '',
            pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
        }
    </script>


<?php $__env->stopSection(); ?>

<!-------------------charts end-------------------->











<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                    <div class="rounded_photo_width_is_to_rest">

                        <div class="content_container center_element">

                        <?php if(Session::get('ACCOUNTANTS_IMAGE')): ?>

                            <img class="round_image" src="<?php echo e(asset('storage/account_profile_pictures/'.Session::get('ACCOUNTANTS_IMAGE'))); ?>" alt="" width="100%">

                        <?php elseif(Session::get('ACCOUNTANTS_GENDER')=='male' || Session::get('ACCOUNTANTS_GENDER')=='Male'): ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-account-half-length-portrait-vector-male.png')); ?>" alt="" width="100%">

                        <?php elseif(Session::get('ACCOUNTANTS_GENDER')=='female' || Session::get('ACCOUNTANTS_GENDER')=='Female'): ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-employee-half-length-portrait-vector-female.png')); ?>" alt="" width="100%">

                        <?php else: ?>

                            <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/Profile_avatar_placeholder_large.png')); ?>" alt="" width="100%">

                        <?php endif; ?>

                        </div>




                        <div class="span_hidden_bar">

                            <div class="info content_container_bg_less">

                                <p class="collected_info">Name</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('ACCOUNTANTS_NAME')); ?></p>

                                <p class="collected_info">Email</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('ACCOUNTANTS_EMAIL')); ?></p>

                                <p class="collected_info">Phone</p>
                                <p class="collected_info">:</p>
                                <p class="collected_info"><?php echo e(Session::get('ACCOUNTANTS_PHONE')); ?></p>

                            </div>

                            <a class="purple_icon" href="<?php echo e(url('/accounts/edit_profile')); ?>">
                                <i class="fas fa-user-edit log_out_btn purple_icon"></i>
                            </a>

                        </div>

                    </div>




                <!--Session message-->

                <?php if(session('msg')=='Profile updated successfully.'): ?>

                    <div class="content_container_bg_less_thin text_center success_msg"><?php echo e(session('msg')); ?></div> 

                <?php endif; ?>



                <div class="purple_line"></div>
                <div class="gap"></div>






                <!--donut chart-->

                <div class="patient_and_doctor_info_one_is_to_one">

                    <div id="donutchart" style="width: 500px; height: 300px;" class="content_container_bg_less"></div>

                    <div>

                        <div class="content_container_thin title_bar_purple">Accounts setup</div>

                        <div class="options">

                            <form action="<?php echo e(url('/update/commission/')); ?>" method="post" class="option_container">
                            <?php echo csrf_field(); ?>

                                <div class="content_container">

                                    <input class="option_input" type="tel" name="commission" value="<?php echo e(Session::get('COMMISSION')); ?>" placeholder="%" required>

                                </div>

                                <div class="option_label_btn_bar">

                                    <label for="patient_cap" class="content_container_thin text_center center_element">Commission</label>
                                    <button type="submit" class="content_container_bg_less_thin btn form_btn"><i class="fas fa-check-square log_out_btn"></i></button>

                                </div>

                            </form>

                            <form action="<?php echo e(url('/update/vat/')); ?>" method="post" class="option_container">
                            <?php echo csrf_field(); ?>

                                <div class="content_container">

                                    <input class="option_input" type="tel" name="vat" value="<?php echo e(Session::get('VAT')); ?>" placeholder="%" required>

                                </div>

                                <div class="option_label_btn_bar">

                                    <label for="patient_cap" class="content_container_thin text_center center_element">Tax</label>
                                    <button type="submit" class="content_container_bg_less_thin btn form_btn"><i class="fas fa-check-square log_out_btn"></i></button>

                                </div>

                            </form>

                        </div>

                    </div>
                
                </div>








<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/home.blade.php ENDPATH**/ ?>