

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type',"Doctor's Income"); ?>








<!--------------------charts----------------------->

<?php $__env->startSection('charts'); ?>



<?php $__env->stopSection(); ?>

<!-------------------charts end-------------------->











<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



<form action="<?php echo e(url('/accounts/doctor/income/filter/')); ?>" method="post" class="content_container patient_info_form">
<?php echo csrf_field(); ?>

    <div class="doctor_search_form_element">

        <label for="doctor_name_search" class="collected_info vanish_label">Search Doctor</label>

        <div class="patient_and_doctor_info_one_is_to_one">

            <input type="text" class="input" name="doctor_search_info" placeholder="Enter Doctor Name or ID">

            <select name="department" id="department" class="input" required>

                <option value="All">All</option>

                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($list->Department); ?>"><?php echo e($list->Department); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </div>

        <button type="submit" class="btn form_btn" name="search_doctor">Search</button>

    </div>

</form>



<div class="purple_line"></div>
<div class="gap"></div>


    <div class="content_container_bg_less_thin">

        <span></span>
            
            <p><b><?php echo e(Session::get('doctor_salary_filter_type')); ?></b></p>

        <span></span>

    </div>



<div class="doctors_list">

    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!--<a href="<?php echo e(url('/accounts/doctor/income/select/')); ?>">-->
    <form class="doctor_list_item" action="<?php echo e(url('/accounts/doctor/income/details/')); ?>" method="post">
    <?php echo csrf_field(); ?>
        <input type="hidden" name="d_id" value="<?php echo e($doctor->D_ID); ?>">
        <input type="hidden" name="dr_name" value="<?php echo e($doctor->Dr_Name); ?>">
        <button type="submit" name="select_doctor" class="btn capsule">

        

            <?php if($doctor->Dr_Image): ?>

                <img class="round_image" src="<?php echo e(asset('storage/doctor_profile_pictures/'.$doctor->Dr_Image)); ?>" alt="" width="100%">

            <?php elseif($doctor->Dr_Gender=='male' || $doctor->Dr_Gender=='Male'): ?>

                <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-male.png')); ?>" alt="" width="100%">

            <?php elseif($doctor->Dr_Gender=='female' || $doctor->Dr_Gender=='Female'): ?>

                <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-female.png')); ?>" alt="" width="100%">

            <?php else: ?>

                <img class="round_image" src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/Profile_avatar_placeholder_large.png')); ?>" alt="" width="100%">

            <?php endif; ?>

        

            <div class="doctor_name_dept">
                <p class="doctor_name"><?php echo e($doctor->Dr_Name); ?></p>
                <p> Wallet: <?php echo e($doctor->Wallet); ?> tk </p>
            </div>
        </button>
    </form>
    <!--</a>-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>







<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/doctor_income.blade.php ENDPATH**/ ?>