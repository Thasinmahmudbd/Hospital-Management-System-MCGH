

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Reception (Bed Selection)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<?php if(Session::get('bed_selection_type')=='insert'): ?>

    <li class="link_item">
        <a href="<?php echo e(url('/reception/doctor_selection')); ?>" class="link">
            <i class="link_icons fas fa-user-md"></i>
            <span class="link_name"> Reselect Consultant </span>
        </a>
    </li>
    <li class="link_item">
        <a href="<?php echo e(url('/reception/cancel/admission')); ?>" class="link">
            <i class="link_icons far fa-window-close"></i>
            <span class="link_name"> Cancel Admission </span>
        </a>
    </li>

<?php elseif(Session::get('bed_selection_type')=='update'): ?>

    <li class="link_item">
        <a href="<?php echo e(url('/reception/cancel/bed/switch')); ?>" class="link">
            <i class="link_icons fas fa-undo-alt"></i>
            <span class="link_name"> Cancel Bed Switch </span>
        </a>
    </li>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<?php if(Session::get('bed_selection_type')=='insert'): ?>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/doctor_selection')); ?>">Reselect Consultant</a>
    </div>
    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/cancel/admission')); ?>">Cancel Admission</a>
    </div>

<?php elseif(Session::get('bed_selection_type')=='update'): ?>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/cancel/bed/switch')); ?>">Cancel Bed Switch</a>
    </div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                <!--Links to navigate invoice pages-->

                <div class="content_nav">

                <?php if(Session::get('BED_TYPE')=='male_ward'): ?>
                    <a href="/reception/ward/male" class="content_nav_link_active">Male Ward</a>
                <?php else: ?>
                    <a href="/reception/ward/male" class="content_nav_link">Male Ward</a>
                <?php endif; ?>

                <?php if(Session::get('BED_TYPE')=='female_ward'): ?>
                    <a href="/reception/ward/female" class="content_nav_link_active">Female Ward</a>
                <?php else: ?>
                    <a href="/reception/ward/female" class="content_nav_link">Female Ward</a>
                <?php endif; ?>

                <?php if(Session::get('BED_TYPE')=='child_ward'): ?>
                    <a href="/reception/ward/child" class="content_nav_link_active">Child Ward</a>
                <?php else: ?>
                    <a href="/reception/ward/child" class="content_nav_link">Child Ward</a>
                <?php endif; ?>

                <?php if(Session::get('BED_TYPE')=='cabin'): ?>
                    <a href="/reception/cabin" class="content_nav_link_active">Cabin</a>
                <?php else: ?>
                    <a href="/reception/cabin" class="content_nav_link">Cabin</a>
                <?php endif; ?>

                <?php if(Session::get('bed_selection_type')=='insert'): ?>
                    <a href="/reception/ward/cabin/none" class="content_nav_link table_item_red">None</a>
                <?php endif; ?>

                </div>







                <div class="purple_line"></div>
                <div class="gap"></div>







                <!--Session message-->

                <?php if(session('msg')=='This bed is already taken. Please pick another one.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

                <?php endif; ?>







                <!--Showing beds-->

                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="10%" class="frame_header_item">Bed No</th>
                        <th width="15%" class="frame_header_item">Quality</th>
                        <th width="10%" class="frame_header_item">Room No</th>
                        <th width="25%" class="frame_header_item">Bed Location</th>
                        <th width="15%" class="frame_header_item">Normal Price</th>
                        <th width="15%" class="frame_header_item">Package Price</th>
                        <th width="5%" class="frame_header_item">Pick</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $bed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Bed No"><?php echo e($list->Bed_No); ?></td>
                        <td class="frame_data" data-label="Quality"><?php echo e($list->Quality); ?></td>
                        <td class="frame_data" data-label="Room No"><?php echo e($list->Room_No); ?></td>
                        <td class="frame_data" data-label="Bed Location"><?php echo e($list->B_Location); ?></td>
                        <td class="frame_data" data-label="Normal Price"><?php echo e($list->Normal_Pricing); ?></td>
                        <td class="frame_data" data-label="Package Price"><?php echo e($list->Package_Pricing); ?></td>

                        <?php if($list->Confirmation == '0'): ?>
                            <td class="frame_action" data-label="Pick">
                                <a href="<?php echo e(url('/reception/bed/confirmation/'.$list->B_ID)); ?>">
                                    <i class="fas fa-check-circle table_btn"></i>
                                </a>
                            </td>
                        <?php else: ?>
                            <td class="frame_action disable shade" data-label="Pick">
                                <a href="">
                                    <i class="fas fa-times-circle table_btn_red"></i>
                                </a>
                            </td>
                        <?php endif; ?>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/beds.blade.php ENDPATH**/ ?>