

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Reception (Patients List)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/home/')); ?>" class="link">
        <i class="link_icons fas fa-window-maximize"></i>
        <span class="link_name"> Patient Entry </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/emergency/')); ?>" class="link">
        <i class="link_icons fas fa-first-aid"></i>
        <span class="link_name"> Emergency </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/patient_list/'.Session::get('DATE_TODAY'))); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Daily Summary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Generate Invoice </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/reception/home/')); ?>">Patient Entry</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/emergency/')); ?>">Emergency</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/patient_list/'.Session::get('DATE_TODAY'))); ?>">Daily Summary</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>">Generate Invoice</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>





                <div class="patient_and_doctor_info_one_is_to_one">

                    <p class="content_container_bg_less_thin text_center alert_msg">
                        You've collected : <?php echo e(Session::get('collection')); ?> Tk.
                    </p>

                    <form action="<?php echo e(url('/reception/filter/summary/')); ?>" method="post" class="content_container_white_super_thin center_self">
                    <?php echo csrf_field(); ?>

                        <div class="patient_form_element_three_is_to_one">

                            <input type="date" class="input" name="summary_date" value="<?php echo e(Session::get('DATE_TODAY')); ?>" required>
                            <button type="submit" class="btn form_btn" name="search_summary">Filter</button>

                        </div>

                    </form>



                </div>





                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="60%" class="frame_header_item">Transaction Message</th>
                        <th width="20%" class="frame_header_item">Timestamp</th>
                        <th width="15%" class="frame_header_item">Amount Collected</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data text_left" data-label="Transaction Message">Appointment for <?php echo e($list->P_ID); ?> with <?php echo e($list->D_ID); ?>.</td>
                        <td class="frame_data" data-label="Timestamp"><?php echo e($list->Time_Stamp); ?></td>
                        <td class="frame_data text_right" data-label="Amount Collected"><?php echo e($list->Final_Fee); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data text_left" data-label="Transaction Message"><?php echo e($list->Message); ?></td>
                        <td class="frame_data" data-label="Timestamp"><?php echo e($list->Time_Stamp); ?></td>
                        <td class="frame_data text_right" data-label="Amount Collected"><?php echo e($list->Credit); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>













<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->
<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/patient_list.blade.php ENDPATH**/ ?>