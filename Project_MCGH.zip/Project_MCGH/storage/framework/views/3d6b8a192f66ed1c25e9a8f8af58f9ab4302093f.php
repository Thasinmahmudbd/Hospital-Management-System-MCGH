

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Dental Service Selection'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/cancel_test/dental/')); ?>" class="link">
        <i class="link_icons fas fa-home"></i>
        <span class="link_name"> Go Home </span>
    </a>
</li>

<li class="link_item">
    <a href="<?php echo e(url('/reception/show_tests/dental/')); ?>" class="link">
        <i class="link_icons fas fa-th-list"></i>
        <span class="link_name"> All Test </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/reception/cancel_test/dental/')); ?>">Go Home</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/show_tests/dental/')); ?>">All Test</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                <div class="patient_and_doctor_info_one_is_to_three">

                    <!--Links to navigate invoice pages-->

                    <span></span>

                    <!--Search bar to search patients-->

                    <form action="<?php echo e(url('/reception/find_test/dental/by_search/')); ?>" method="post" class="content_container_white_super_thin center_self">
                    <?php echo csrf_field(); ?>

                        <div class="patient_form_element_three_is_to_one">

                            <input type="text" class="input" name="test_search_info" placeholder="Enter Test Name" required>

                            <div class="patient_and_doctor_info_one_is_to_one">

                                <button type="submit" class="btn form_btn" name="search_old_patient">Search</button>

                                <a class="btn form_btn text_center" href="<?php echo e(url('/reception/dental/test/payment/')); ?>">Next</a>

                            </div>

                        </div>

                    </form>

                </div>







            <!--Session message-->

            <?php if(session('msg')=='Patient registered, choose tests to proceed.'): ?>

            <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div> 

            <?php elseif(session('msg')=='Test selected.'): ?>

            <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

            <?php elseif(session('msg')=='Test deleted.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

            <?php elseif(session('msg')=='Already selected.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

            <?php endif; ?>










                <!--Selected tests-->

                <div class="purple_line"></div>
                <div class="gap"></div>

                <!--Showing all of dental tests-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Selected Tests</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="50%" class="frame_header_item">Test Name</th>
                        <th width="20%" class="frame_header_item">Rate</th>
                        <th width="20%" class="frame_header_item">Fee</th>
                        <th width="5%" class="frame_header_item">Action</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Test Name"><?php echo e($list->Test_Name); ?></td>
                        <td class="frame_data" data-label="Rate"><?php echo e($list->Rate); ?></td>

                            <td class="frame_data" data-label="Fee"><?php echo e($list->Fee); ?></td>

                            <td class="frame_action" data-label="Action">
                                <a href="<?php echo e(url('/reception/unselect/test/dental/'.$list->AI_ID)); ?>">
                                    <i class="table_btn_red fas fa-times-circle"></i>
                                </a>
                            </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>










            <?php if(Session::get('dental_test_search')=='1'): ?>

                <div class="gap"></div>

                <!--Showing search results of dental tests-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Search Result</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="50%" class="frame_header_item">Test Name</th>
                        <th width="20%" class="frame_header_item">Rate</th>
                        <th width="20%" class="frame_header_item">Fee</th>
                        <th width="5%" class="frame_header_item">Action</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Test Name"><?php echo e($list->Test_Name); ?></td>
                        <td class="frame_data" data-label="Rate"><?php echo e($list->Rate); ?></td>

                        <form action="<?php echo e(url('/reception/select/test/dental/')); ?>" method="post" class="content_container_white_super_thin center_self">
                        <?php echo csrf_field(); ?>

                            <td class="frame_data" data-label="Fee">
                                <input class="input" type="text" name="test_fee" required>
                                <input type="hidden" value="<?php echo e($list->AI_ID); ?>" name="test_id">
                                <input type="hidden" value="<?php echo e(Session::get('dental_test_no')); ?>" name="test_no">
                            </td>

                            <td class="frame_action" data-label="Action">
                                <button type="submit" class="btn_less">
                                    <i class="fas fa-plus-circle table_btn"></i>
                                </button>
                            </td>

                        </form>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>



                <div class="gap"></div>





            <?php elseif(Session::get('dental_test_search')=='0'): ?>

                <div class="gap"></div>

                <!--Showing search results of dental tests when no result-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Search Result</b></p>

                    <span></span>

                </div>

                <div class="warning_msg content_container_bg_less_thin">

                    <p class="text_center">No Tests Here.</p>

                </div>





            <?php elseif(Session::get('dental_test_search')=='3'): ?>

                <div class="gap"></div>

                <!--Showing all of dental tests-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Dental Tests</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="50%" class="frame_header_item">Test Name</th>
                        <th width="20%" class="frame_header_item">Rate</th>
                        <th width="20%" class="frame_header_item">Fee</th>
                        <th width="5%" class="frame_header_item">Action</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Test Name"><?php echo e($list->Test_Name); ?></td>
                        <td class="frame_data" data-label="Rate"><?php echo e($list->Rate); ?></td>

                        <form action="<?php echo e(url('/reception/select/test/dental/')); ?>" method="post" class="content_container_white_super_thin center_self">
                        <?php echo csrf_field(); ?>

                            <td class="frame_data" data-label="Fee">
                                <input class="input" type="text" name="test_fee" required>
                                <input type="hidden" value="<?php echo e($list->AI_ID); ?>" name="test_id">
                                <input type="hidden" value="<?php echo e(Session::get('dental_test_no')); ?>" name="test_no">
                            </td>

                            <td class="frame_action" data-label="Action">
                                <button type="submit" class="btn_less">
                                    <i class="fas fa-plus-circle table_btn"></i>
                                </button>
                            </td>

                        </form>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            <?php endif; ?>









<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->
<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/dental_tests.blade.php ENDPATH**/ ?>