function triggerClick() {
	document.querySelector('#place_holder').click();
}

