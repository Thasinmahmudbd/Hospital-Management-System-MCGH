

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Nurse (Others)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/nurse/home/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patient List </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/nurse/home/')); ?>">Patient List</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>







                    <div class="patient_form_element_one_is_to_one">

                        <div class="block">

                            <div class="content_container_bg_less">

                                <p class="section_title">Patient Info</p>

                                <div class="info">

                                    <p class="collected_info">Patients's Name</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('patient_name')); ?></p>

                                </div>

                            </div>

                            <div class="content_container_bg_less">

                                <p class="section_title">Bed Info</p>

                                <div class="info">

                                    <p class="collected_info">Bed No</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('bed_no')); ?></p>

                                    <p class="collected_info">Floor No</p>
                                    <p>:</p>
                                    <p class="collected_info"><?php echo e(Session::get('floor_no')); ?></p>

                                </div>

                            </div>

                        </div>

                        <div class="block">

                            <div class="gap"></div>

                            <table class="frame_table">

                                <tr class="frame_header">
                                    <th width="70%" class="frame_header_item">Service</th>
                                    <th width="20%" class="frame_header_item">Quantity</th>
                                    <th width="10%" class="frame_header_item">Action</th>
                                </tr>

                                <tr class="frame_rows">

                                    <!--enter others-->
                                    <form action="<?php echo e(url('/nurse/other/input')); ?>" class="content_container patient_info_form" method="post">
                                    <?php echo csrf_field(); ?>

                                    <td class="frame_data" data-label="Service">
                                        <select name="service" id="service" class="input_less" required>
                                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($list->AI_ID); ?>"><?php echo e($list->Other_Name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>

                                    <td class="frame_data" data-label="Quantity">
                                        <input type="text" class="input"  name="quantity" required>
                                    </td>

                                    <td class="frame_action table_item_dark_green" data-label="Action No">
                                        <input type="submit" class="table_item_dark_green btn cover"  value="Next" name="next">
                                    </td>

                                    </form>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="purple_line"></div>
                    <div class="gap"></div>

                    <div class="content_container_bg_less_thin">

                        <span></span>
                            
                        <p><b>Patient Chart</b></p>

                        <span></span>

                    </div>

                    <table class="frame_table">

                        <tr class="frame_header">
                            <th width="5%" class="frame_header_item">S/N</th>
                            <th width="20%" class="frame_header_item">Invigilator</th>
                            <th width="20%" class="frame_header_item">Nurse</th>
                            <th width="20%" class="frame_header_item">Assistant</th>
                            <th width="15%" class="frame_header_item">Services</th>
                            <th width="5%" class="frame_header_item">Quantity</th>
                            <th width="15%" class="frame_header_item">Timestamp</th>
                        </tr>

                        <?php $serial = 1; ?>
                        <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="frame_rows">
                            <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                            <td class="frame_data" data-label="Invigilator"><?php echo e($list->D_ID); ?></td>
                            <td class="frame_data" data-label="Nurse"><?php echo e($list->Duty_N_ID); ?></td>
                            <td class="frame_data" data-label="Assistant"><?php echo e($list->Assistant_Name); ?></td>
                            <td class="frame_data" data-label="Services"><?php echo e($list->Others); ?></td>
                            <td class="frame_data" data-label="Quantity"><?php echo e($list->Others_Use_Count); ?></td>
                            <td class="frame_data" data-label="Timestamp"><?php echo e($list->Timestamp); ?></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>








<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/nurse/other_input.blade.php ENDPATH**/ ?>