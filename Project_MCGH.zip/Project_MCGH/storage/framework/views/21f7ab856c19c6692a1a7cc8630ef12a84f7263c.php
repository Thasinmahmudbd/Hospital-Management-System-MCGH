

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Cash In (Full List)'); ?>








<!--------------------charts----------------------->

<?php $__env->startSection('charts'); ?>



<?php $__env->stopSection(); ?>

<!-------------------charts end-------------------->











<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>





<div class="patient_form_element_one_is_to_one">

    <div class="patient_form_element_one_is_to_three">

        <a class="content_container_thin title_bar_purple btn form_btn" href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>">Refresh</a>

        <p class="content_container_bg_less_thin text_left">
            before every action is recommended.
        </p>

    </div>

    <form action="<?php echo e(url('/account/filter/cash/in/')); ?>" method="post" class="content_container_white_super_thin center_self">
    <?php echo csrf_field(); ?>

        <div class="patient_form_element_three_is_to_one">

            <input type="date" class="input" name="summary_date" value="<?php echo e(Session::get('DATE_TODAY')); ?>" required>
            <button type="submit" class="btn form_btn" name="search_summary">Filter</button>

        </div>

    </form>

</div>




<div class="purple_line"></div>
<div class="gap"></div>







        <!--Session message-->

        <?php if(session('msg')=='Cash in successful.'): ?>

        <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

        <?php elseif(session('msg')=='Total cash-in can not be greater then collected amount.'): ?>

        <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

        <?php elseif(session('msg')=='Not fully cashed, due remains.'): ?>

        <div class="content_container text_center alert_msg"><?php echo e(session('msg')); ?></div>

        <?php endif; ?>







        <table class="frame_table">
            
            <tr class="frame_header">
                <th width="5%" class="frame_header_item">S/N</th>
                <th width="15%" class="frame_header_item">Date</th>
                <th width="15%" class="frame_header_item">R-ID</th>
                <th width="15%" class="frame_header_item">Receptionist</th>
                <th width="15%" class="frame_header_item">Collected (TK)</th>
                <th width="15%" class="frame_header_item">Cashed In (TK)</th>
                <th width="15%" class="frame_header_item">Cash In (TK)</th>
                <th width="5%" class="frame_header_item">Action</th>
            </tr>

            <?php $serial = 1; ?>
            <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(url('/account/filter/cash/in/cashed/')); ?>" method="post" class="span_hidden_bar content_container_bg_less_thin center_element">
            <?php echo csrf_field(); ?>

            <tr class="frame_rows">
                <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                <td class="frame_data" data-label="Date"><?php echo e($item->Cash_In_Date); ?></td>
                <td class="frame_data" data-label="R-ID"><?php echo e($item->R_ID); ?></td>
                <td class="frame_data" data-label="Receptionist"><?php echo e($item->R_Name); ?></td>
                <td class="frame_data" data-label="Collected"><?php echo e($item->Cash_In_Amount); ?></td>
                <td class="frame_data" data-label="Cashed In"><?php echo e($item->Amount_Received); ?></td>
                <td class="frame_data" data-label="Cash In">

                    <input class="input" type="tel" name="cashed_amount" required> 
                    <input class="input" type="hidden" name="ai_id" value="<?php echo e($item->AI_ID); ?>"> 

                </td>

                <td class="frame_action" data-label="Action">

                    <button class="btn_less" type="submit" name="submit"> 

                        <i class="fas fa-check-circle table_btn"></i>

                    </button>

                </td>
            </tr>

            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/cash_in.blade.php ENDPATH**/ ?>