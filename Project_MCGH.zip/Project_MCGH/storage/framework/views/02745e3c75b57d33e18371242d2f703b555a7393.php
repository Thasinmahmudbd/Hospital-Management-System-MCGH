

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Log Details'); ?>








<!--------------------charts----------------------->

<?php $__env->startSection('charts'); ?>



<?php $__env->stopSection(); ?>

<!-------------------charts end-------------------->











<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/'.Session::get('DATE_TODAY'))); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

<div class="content_container_bg_less_thin">

<span></span>
    
    <p><b>Search Logs</b></p>

<span></span>

</div>





<form action="<?php echo e(url('/accounts/doctor/income/details/filter/')); ?>" method="post" class="span_hidden_bar content_container_bg_less_thin center_element">
<?php echo csrf_field(); ?>

    <div class="patient_and_doctor_info_one_is_to_one">

        <div class="patient_form_element_one_is_to_three center_element content_container">
            <label class="center_element" for="search_from">From</label>
            <input class="input" type="date" name="search_from" required>  
        </div>

        <div class="patient_form_element_one_is_to_three center_element content_container">
            <label class="center_element" for="search_to">To</label>
            <input class="input" type="date" name="search_to" required>  
        </div>

    </div>

    <div>

        <button class="btn form_btn" type="submit" name="submit"> 
            <i class="fas fa-search log_out_btn"></i>
        </button>

    </div>

</form>




<div class="purple_line"></div>
<div class="gap"></div>


<div class="content_container_bg_less_thin">

    <span></span>

        <?php if(Session::get('from')!='none'): ?>

            <div class="patient_form_element_three_is_to_one">

                <p><b>Log details</b> of <?php echo e(Session::get('Dr_Name')); ?> (<?php echo e(Session::get('D_ID')); ?>). From <?php echo e(Session::get('from')); ?> To <?php echo e(Session::get('to')); ?>.</p>

                <form class="text_right" action="<?php echo e(url('/accounts/doctor/income/details/')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="d_id" value="<?php echo e(Session::get('D_ID')); ?>">
                    <input type="hidden" name="dr_name" value="<?php echo e(Session::get('Dr_Name')); ?>">
                    <input type="submit" name="select_doctor" value="Show All" class="btn_less btn text_link">
                </form>

            </div>

        <?php else: ?>

            <p><b>Log details</b> of <?php echo e(Session::get('Dr_Name')); ?> (<?php echo e(Session::get('D_ID')); ?>). </p> 

        <?php endif; ?>

    <span></span>

</div>





        <table class="frame_table">
            
            <tr class="frame_header">
                <th width="5%" class="frame_header_item">S/N</th>
                <th width="19" class="frame_header_item">Timestamp</th>
                <th width="19%" class="frame_header_item">Debit</th>
                <th width="19%" class="frame_header_item">Credit</th>
                <th width="19%" class="frame_header_item">Income</th>
                <th width="19%" class="frame_header_item">Current Balance</th>
            </tr>

            <?php $serial = 1; ?>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="frame_rows">
                <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                <td class="frame_data" data-label="Timestamp"><?php echo e($log->Time_Stamp); ?></td>
                <td class="frame_data text_right" data-label="Debit"><?php echo e($log->Debit); ?></td>
                <td class="frame_data text_right" data-label="Credit"><?php echo e($log->Credit); ?></td>
                <td class="frame_data text_right" data-label="Income"><?php echo e($log->Income); ?></td>

                <?php if(Session::get('from')!='none'): ?>
                    <td class="frame_data text_right" data-label="Current Balance"><?php echo e($log->Current_Balance); ?></td>
                <?php else: ?>
                    <td class="frame_data text_right first_child_indicator_animation" data-label="Current Balance"><?php echo e($log->Current_Balance); ?></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/doctor_income_details.blade.php ENDPATH**/ ?>