

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Profile'); ?>








<!--------------------charts----------------------->

<?php $__env->startSection('charts'); ?>



<?php $__env->stopSection(); ?>

<!-------------------charts end-------------------->











<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/')); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/')); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('')); ?>" method="post" class="span_hidden_bar content_container_bg_less_thin center_element">
<?php echo csrf_field(); ?>

    <div class="patient_form_element_one_is_to_one_is_to_one">

        <div class="patient_form_element_one_is_to_three center_element content_container">
            <label class="center_element" for="search_from">From</label>
            <input class="input" type="date" name="search_from" required>  
        </div>

        <div class="patient_form_element_one_is_to_three center_element content_container">
            <label class="center_element" for="search_to">To</label>
            <input class="input" type="date" name="search_to" required>  
        </div>

        <select name="type" id="type" class="input content_container_white_thin" required>

            <option value="">All</option>
            <option value="">Tax</option>
            <option value="">Total Income</option>
            <option value="">Total Profit</option>
            <option value="">Current Balance</option>

        </select>

    </div>

    <div>

        <button class="btn form_btn" type="submit" name="submit"> 
            <i class="fas fa-search log_out_btn"></i>
        </button>

    </div>

</form>




<div class="purple_line"></div>
<div class="gap"></div>


<div class="content_container_bg_less_thin">

    <span></span>
        
        <p><b>Logs</b></p>

    <span></span>

</div>

                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="10%" class="frame_header_item">Date</th>
                        <th width="30%" class="frame_header_item">Message</th>
                        <th width="15%" class="frame_header_item">Debit</th>
                        <th width="15%" class="frame_header_item">Credit</th>
                        <th width="15%" class="frame_header_item">Total Income</th>
                        <th width="15%" class="frame_header_item">Total Profit</th>
                    </tr>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="Date"></td>
                        <td class="frame_data" data-label="Message"></td>
                        <td class="frame_data" data-label="Debit"></td>
                        <td class="frame_data" data-label="Credit"></td>
                        <td class="frame_data" data-label="Total Income"></td>
                        <td class="frame_data" data-label="Total Profit"></td>
                    </tr>

                </table>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/logs.blade.php ENDPATH**/ ?>