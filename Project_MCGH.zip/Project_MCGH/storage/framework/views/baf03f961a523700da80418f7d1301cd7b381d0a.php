

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','OT (New Entry)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/ot/home/')); ?>" class="link">
        <i class="link_icons fas fa-window-maximize"></i>
        <span class="link_name"> Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/admission/list/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> New Entry </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/invoice/generate/list/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Invoice </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/ot/home/')); ?>">Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/admission/list/')); ?>">New Entry</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/invoice/generate/list/')); ?>">Invoice</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>












                <!--schedule nav and search-->

                <div class="patient_form_element_one_is_to_one">

                    <div class="content_nav">
        
                        <a href="<?php echo e(url('/ot/schedule/entry/')); ?>" class="content_nav_link">Add schedule</a>

                    </div>

                    <form action="<?php echo e(url('')); ?>" method="post" class="content_container_white_super_thin center_self">
                        <?php echo csrf_field(); ?>

                        <div class="patient_form_element_three_is_to_one">

                            <input type="date" class="input" name="schedule_date" required>
                            <button type="submit" class="btn form_btn" name="schedule_date_search">Search</button>

                        </div>

                    </form>

                </div>

                <div class="purple_line"></div>
                <div class="gap"></div>







                <!--Session message-->

                <?php if(session('msg')=='New schedule added.'): ?>

                    <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

                <?php elseif(session('msg')=='Schedule edited.'): ?>

                    <div class="content_container text_center alert_msg"><?php echo e(session('msg')); ?></div>

                <?php elseif(session('msg')=='Schedule deleted.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

                <?php endif; ?>




                <!--Showing schedules-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Schedules</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="13%" class="frame_header_item">P-ID</th>
                        <th width="13%" class="frame_header_item">Surgeon</th>
                        <th width="20%" class="frame_header_item">Operation Type</th>
                        <th width="5%" class="frame_header_item">OT</th>
                        <th width="10%" class="frame_header_item">Date</th>
                        <th width="10%" class="frame_header_item">Time</th>
                        <th width="10%" class="frame_header_item">Est. Duration</th>
                        <th width="7%" class="frame_header_item">Edit</th>
                        <th width="7%" class="frame_header_item">Delete</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">

                        <form action="<?php echo e(url('/ot/edit/schedule')); ?>" class="content_container patient_info_form" method="post">
                        <?php echo csrf_field(); ?>

                            <td class="frame_data" data-label="S/N" width="5%"><?php echo $serial; $serial++; ?></td>

                            <td class="frame_data" data-label="P-ID" width="13%"><?php echo e($list->P_ID); ?></td>
                            <td class="frame_data" data-label="Surgeon" width="13%"><?php echo e($list->Surgeon_Name); ?></td>
                            <td class="frame_data" data-label="Operation Type" width="20%"><?php echo e($list->Operation_Type); ?></td>

                            <td class="frame_data" data-label="OT" width="5%">
                                <input type="number" class="input_less flexible" name="otno" value="<?php echo e($list->OT_No); ?>" required>
                            </td>

                            <td class="frame_data" data-label="Date" width="10%">
                                <input type="date" class="input_less" name="date" value="<?php echo e($list->Operation_Date); ?>" required>
                            </td>

                            <td class="frame_data" data-label="Time" width="10%">
                                <input type="time" class="input_less" name="time" value="<?php echo e($list->Operation_Start_Time); ?>" required>
                            </td>

                            <td class="frame_data" data-label="Est. Duration" width="10%">
                                <input type="text" class="input_less flexible" name="estDuration" value="<?php echo e($list->Estimated_Duration); ?>" required>
                            </td>

                            <td class="frame_action" data-label="Edit" width="7%">
                                <input type="hidden" name="ai_id" value="<?php echo e($list->AI_ID); ?>">
                                <button type="submit" class="btn_less" required>
                                    <i class="table_btn_orange fas fa-pen"></i>
                                </button>
                            </td>

                            <td class="frame_action" data-label="Delete" width="7%">
                                <a href="<?php echo e(url('/ot/edit/schedule/'.$list->AI_ID)); ?>">
                                    <i class="table_btn_red fas fa-times-circle"></i>
                                </a>
                            </td>

                        </form>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>




<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/ot/home.blade.php ENDPATH**/ ?>