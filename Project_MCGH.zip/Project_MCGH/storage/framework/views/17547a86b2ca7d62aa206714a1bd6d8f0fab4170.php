

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Reception (Emergency)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/home/')); ?>" class="link">
        <i class="link_icons fas fa-window-maximize"></i>
        <span class="link_name"> Patient Entry </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/emergency/')); ?>" class="link">
        <i class="link_icons fas fa-first-aid"></i>
        <span class="link_name"> Emergency </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/patient_list/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patients List </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Generate Invoice </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/reception/home/')); ?>">Patient Entry</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/emergency/')); ?>">Emergency</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/patient_list/')); ?>">Patients List</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>">Generate Invoice</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

    <!--Patient info tab-->

    <div class="patient_and_doctor_info_one_is_to_one">






        <!-- Billing -->

        <div class="content_container_bg_less">

            <p class="section_title">Patient Info</p>

            <form action="<?php echo e(url('/reception/emergency/data/entry/')); ?>" method="post" class="doctor_form">
            <?php echo csrf_field(); ?>

                <div class="info">
                    <p class="collected_info">Patient Name</p>
                    <p>:</p>
                    <input type="text" class="input_less collected_info"  placeholder="Insert Patient Name" name="er_patient_name">
                </div>

                <div class="info">
                    <p class="collected_info">Reference Name</p>
                    <p>:</p>
                    <input type="text" class="input_less collected_info"  placeholder="Insert Reference Name" name="ref_name">
                </div>

                <div class="info">
                    <p class="collected_info">Reference Cell</p>
                    <p>:</p>
                    <input type="text" class="input_less collected_info"  placeholder="Insert Reference Cell" name="ref_cell">
                </div>

                <div class="info">
                    <p class="collected_info">DMO</p>
                    <p>:</p>
                    <select name="dmo" class="input collected_info" required>
                        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->D_ID); ?>"><?php echo e($list->Dr_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="info">
                    <p class="collected_info">Bill</p>
                    <p>:</p>
                    <input type="tel" class="input_less collected_info" name="bill" id="estimate" value="<?php echo e(Session::get('emergency_fee')); ?>" readonly>
                </div>

                <div class="info">
                    <p class="collected_info">Received</p>
                    <p>:</p>
                    <input type="tel" class="input collected_info" name="received" oninput="calcAppointmentFee()" id="r2" value="0" required>
                </div>

                <div class="info">
                    <p class="collected_info">Change</p>
                    <p>:</p>
                    <input type="tel" class="input collected_info" name="change" id="c2" value="0" required>
                </div>

                <div class="info">
                    <span class="collected_info"></span>
                    <p></p>
                    <input type="submit" class="btn form_btn" name="enlist" value="Enlist Patient">
                </div>

            </form>

        </div>











    </div>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/emergency.blade.php ENDPATH**/ ?>