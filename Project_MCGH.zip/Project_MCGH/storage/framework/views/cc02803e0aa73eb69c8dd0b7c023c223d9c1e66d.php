

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','My Schedule'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/doctor/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/patients/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> My Patients </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> My Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/operation/schedule/')); ?>" class="link">
        <i class="link_icons fas fa-calendar-alt"></i>
        <span class="link_name"> Operation Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> My Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/doctor/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/doctor/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/patients/')); ?>">My Patients</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/schedule/')); ?>">My Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/operation/schedule/')); ?>">Operation Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/log/')); ?>">My Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/doctor/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Add a new shift</b></p>

                    <span></span>

                </div>





                <form action="<?php echo e(url('/doctor/add_shift/')); ?>" method="post" class="span_hidden_bar content_container_bg_less_thin center_element">
                <?php echo csrf_field(); ?>

                <div class="patient_and_doctor_info_one_is_to_one">

                    <div class="patient_form_element_one_is_to_three center_element content_container">
                        <label class="center_element" for="from">From</label>
                        <input class="input" type="time" name="from" required>  
                    </div>

                    <div class="patient_form_element_one_is_to_three center_element content_container">
                        <label class="center_element" for="to">To</label>
                        <input class="input" type="time" name="to" required>  
                    </div>

                </div>

                <div>

                    <button class="btn form_btn" type="submit" name="submit"> 
                        <i class="fas fa-plus-circle log_out_btn"></i>
                    </button>

                </div>

                </form>






                    <div class="purple_line"></div>
                    <div class="gap"></div>


                    <div class="content_container_bg_less_thin">

                        <span></span>
                            
                        <p><b>Edit your schedule</b></p>

                        <span></span>
                
                    </div>





                    <table class="frame_table">
                    
                    <tr class="frame_header">

                        <th width="12%" class="frame_header_item">Shift</th>




                        <?php if(Session::get('DAY_TODAY')=='Sat'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Sat</th>

                        <?php else: ?>

                            <th width="12%" class="frame_header_item">Sat</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Sun'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Sun</th>
                            
                        <?php else: ?>

                            <th width="12%" class="frame_header_item">Sun</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Mon'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Mon</th>
                            
                        <?php else: ?>
    
                            <th width="12%" class="frame_header_item">Mon</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Tue'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Tue</th>
                            
                        <?php else: ?>
    
                            <th width="12%" class="frame_header_item">Tue</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Wed'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Wed</th>
                            
                        <?php else: ?>

                            <th width="12%" class="frame_header_item">Wed</th>

                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Thu'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Thu</th>
                            
                        <?php else: ?>
    
                            <th width="12%" class="frame_header_item">Thu</th>
    
                        <?php endif; ?>




                        <?php if(Session::get('DAY_TODAY')=='Fri'): ?>

                            <th width="12%" class="frame_header_item background_indicator_animation">Fri</th>
                            
                        <?php else: ?>
    
                            <th width="12%" class="frame_header_item">Fri</th>
    
                        <?php endif; ?>




                        <th width="4%" class="frame_header_item table_item_red"><i class="fas fa-minus-circle log_out_btn"></i></th>

                    </tr>










                    <?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">

                        <td class="frame_data" data-label="Shift"><?php echo e($time->F); ?> - <?php echo e($time->T); ?></td>




                        <?php if(Session::get('DAY_TODAY')=='Sat'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Sat">

                        <?php else: ?>

                            <td class="frame_data" data-label="Sat">

                        <?php endif; ?>

                                <?php if($time->Sat=='A' || $time->Sat=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Sat')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Sat=='N/A' || $time->Sat=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Sat')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sat); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Sun'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Sun">

                        <?php else: ?>

                            <td class="frame_data" data-label="Sun">

                        <?php endif; ?>

                                <?php if($time->Sun=='A' || $time->Sun=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Sun')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Sun=='N/A' || $time->Sun=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Sun')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Sun); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Mon'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Mon">

                        <?php else: ?>

                            <td class="frame_data" data-label="Mon">

                        <?php endif; ?>

                                <?php if($time->Mon=='A' || $time->Mon=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Mon')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Mon=='N/A' || $time->Mon=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Mon')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Mon); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Tue'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Tue">

                        <?php else: ?>

                            <td class="frame_data" data-label="Tue">

                        <?php endif; ?>

                                <?php if($time->Tue=='A' || $time->Tue=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Tue')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Tue=='N/A' || $time->Tue=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Tue')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Tue); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Wed'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Wed">

                        <?php else: ?>

                            <td class="frame_data" data-label="Wed">

                        <?php endif; ?>

                                <?php if($time->Wed=='A' || $time->Wed=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Wed')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Wed=='N/A' || $time->Wed=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Wed')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Wed); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Thu'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Thu">

                        <?php else: ?>

                            <td class="frame_data" data-label="Thu">

                        <?php endif; ?>

                                <?php if($time->Thu=='A' || $time->Thu=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Thu')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Thu=='N/A' || $time->Thu=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Thu')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Thu); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>




                        <?php if(Session::get('DAY_TODAY')=='Fri'): ?>

                            <td class="frame_data border_indicator_animation" data-label="Fri">

                        <?php else: ?>

                            <td class="frame_data" data-label="Fri">

                        <?php endif; ?>

                                <?php if($time->Fri=='A' || $time->Fri=='a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_n_a/'.$time->AI_ID,'Fri')); ?>" class="">
                                        <p class="table_basic_btn table_item_green">Available</p>
                                    </a>
                                <?php elseif($time->Fri=='N/A' || $time->Fri=='n/a'): ?>
                                    <a href="<?php echo e(url('/doctor/make_a/'.$time->AI_ID,'Fri')); ?>" class="">
                                        <p class="table_basic_btn table_item_red"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/doctor/reschedule/')); ?>" class="">
                                        <p class="table_basic_btn table_item_orange"><?php echo e($time->Fri); ?></p>
                                    </a>
                                <?php endif; ?>

                            </td>



                            <td width="4%" class="table_item_red table_basic_btn" data-label="Delete">

                                <a class="log_out_btn center_element" href="<?php echo e(url('/doctor/delete_shift/'.$time->AI_ID)); ?>">

                                    <i class="fas fa-minus-circle"></i>
                            
                                </a>

                            </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>



                <div class="gap"></div>



    <!--Session message-->
    <?php if(session('msg')=='Seems like there are appointments present in this slot. Reschedule them first in order to edit routine.'): ?>

        <div class="content_container_bg_less_thin text_center warning_msg"><?php echo e(session('msg')); ?></div> 

    <?php elseif(session('msg')=='Seems like there are appointments present in some of the slots. Cancel them first in order to delete shift.'): ?>

        <div class="content_container_bg_less_thin text_center warning_msg"><?php echo e(session('msg')); ?></div>

    <?php elseif(session('msg')=='Shift deleted successfully.'): ?>

        <div class="content_container_bg_less_thin text_center success_msg"><?php echo e(session('msg')); ?></div>

    <?php elseif(session('msg')=='Shift added successfully.'): ?>

        <div class="content_container_bg_less_thin text_center success_msg"><?php echo e(session('msg')); ?></div>

    <?php endif; ?>









                

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Options</b></p>

                    <span></span>

                </div>









                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="options">

                    <form action="<?php echo e(url('/doctor/set_patient_cap/')); ?>" method="post" class="option_container">
                    <?php echo csrf_field(); ?>

                        <div class="content_container">

                            <input class="option_input" type="tel" name="patient_cap" value="<?php echo e($data->Patient_Cap); ?>" required>

                        </div>

                        <div class="option_label_btn_bar">

                            <label for="patient_cap" class="content_container_thin text_center center_element">Patients</label>
                            <button type="submit" class="content_container_bg_less_thin btn form_btn"><i class="fas fa-check-square log_out_btn"></i></button>

                        </div>

                    </form>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>










<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/doctor/schedule.blade.php ENDPATH**/ ?>