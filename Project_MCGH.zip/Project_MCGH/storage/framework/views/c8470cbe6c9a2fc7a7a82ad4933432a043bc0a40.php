<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <title>invoice</title>

    <style>

        .invoice{
            height: 100%;
            width: 90%;
            margin: auto;
            margin-top: 0px;
            font-family: arial,sans-serif,helvetica;
        }

        .header{
            background-color: #f2f2f2;
            font-size: 12px;
            text-align: center;
            padding: 3px;
            color: black;
            font-weight: bold;
        }

        .main {
            text-align: center;
            margin-top: 10px;
        }

        .m_invoic{
            width: 100%;
            margin-top: 5px;
            text-align: center;
            background-color: #f2f2f2;
            color: black;
            font-size: 13px;
            padding: 3px;
            font-weight: bold;
        }

        .Patient_Details_table{
            margin-top: 10px;
            width: 100%;
            font-size: 13px;
        }

        .test_table{
            border: 1px solid black;
            padding: 2px; 
            font-size: 11px;
            text-align: center;
        }

        table{
            border-collapse: collapse;
        }

        .tr{
            line-height:1.8;
        }

        .total_les_due1 {
            padding: 3px; 
            font-size: 12px;
            text-align: right;
        }

        .total_les_due2 {
            border: 1px solid black;
            padding: 3px; 
            font-size: 12px;
            text-align: right;
        }

        .test_table_border_less{
            padding: 2px; 
            font-size: 11px;
            text-align: right;
            font-weight:bold;
        }

        .test_table_border{
            border: 1px solid black;
            padding: 2px; 
            font-size: 11px;
            text-align: right;
        }

    </style>

</head>

<body class="invoice">

    <!--Header start-->
    <table class="main" style="width:100%">

        <div class="header">সেনাবাহিনীর তত্ত্বাবধানে পরিচালিত, সর্ব সাধারনের জন্য উন্মুক্ত</div>

        <tr>
            <td style="line-height: 130%;">
                <div style="font-size:15px;">ময়নামতি ক্যান্টনম্যান্ট জেনারেল হসপিটাল</div>
                <div style="font-size:13px;">MAINAMATI CANTONMENT GENERAL HOSPITAL</div>
                <div style="font-size:11px;">টিপরা বাজার,কুমিল্লা সেনানিবাস</div>
                <div style="font-size:10px;">মোবাইল-০১৭৩০-০৮৭৯৪৯,মোবাইল-০১৭৩০-০৮৭৯৩৯ </div>
            </td> 
        </tr>

    </table><!--Header end-->


    <table class="m_invoic">

        <tr>
            <td>INVOICE</td>
        </tr>

    </table>


    <!--Patient_Details_table_start-->
    <table class="Patient_Details_table" >

        <tr class="tr"> 
            <td colspan="2"><b>Receptionist:</b> <?php echo e(Session::get('R_NAME')); ?> (<?php echo e(Session::get('rId')); ?>)</td>
            <td style="width: 40%;" ><b>Registration Date:</b> <?php echo e(Session::get('reg_date')); ?></td>
        </tr>

        <tr class="tr"> 
            <td colspan="2"><b>Patient ID:</b> <?php echo e(Session::get('pId')); ?></td>
            <td style="width: 40%;" ><b>Delivery Date:</b> <?php echo e(Session::get('del_date')); ?></td>
        </tr>

        <tr class="tr">
            <td colspan="3"><b>Patient Name:</b> <?php echo e(Session::get('pName')); ?></td>
        </tr>

        <tr class="tr"> 
            <td style="width: 30%;"><b>Gender:</b> <?php echo e(Session::get('pGender')); ?></td>
            <td style="width: 30%;"> <b>Age:</b> <?php echo e(Session::get('pAge')); ?></td>
            <td style="width: 40%;"><b>Phone:</b> <?php echo e(Session::get('cellNum')); ?></td>
        </tr>

        <tr class="tr">
            <td colspan="3"><b>Refer:</b> <?php echo e(Session::get('dName')); ?></td>
        </tr>

    </table><!--Patient_Details_table_end-->


    <!--test_details table start-->
    <table style="width:100%;margin-top: 10PX;">

        <tr>
            <th class= "test_table"style="width:8%;">S/N</th>
            <th class= "test_table" style="width:60%">Test Name</th>
            <th  class= "test_table"style="width:14%">Room No</th>
            <th  class= "test_table"style="width:18%">Amount</th>
        </tr>

        <?php $serial = 1; ?>

        <tr>
            <td class= "test_table"><?php echo $serial; $serial++; ?></td>
            <td class= "test_table">Physio</td>
            <td class= "test_table"></td>
            <td class= "test_table"style="text-align: right;"><?php echo e(Session::get('fee')); ?></td>
        </tr>

    </table><!--test_details table end-->


    <!--total_less-due start-->
    <table style="width:100%">

        <tr>
            <td class= "test_table_border_less" style="width:8%"></td>
            <td class= "test_table_border_less" style="width:60%"></td>
            <td class= "test_table_border_less" style="width:14%">Received:</td>
            <td class= "test_table_border" style="width:18%" ><?php echo e(Session::get('received')); ?></td>
        </tr>

        <tr>
            <td class= "test_table_border_less" style="width:8%"></td>
            <td class= "test_table_border_less" style="width:60%"></td>
            <td class= "test_table_border_less" style="width:14%">Change:</td>
            <td class= "test_table_border" style="width:18%" ><?php echo e(Session::get('changes')); ?></td>
        </tr>

    </table><!--total_less-due end-->


    <table class="m_invoic" style="margin-top: 10px;">

        <tr>
            <td>ময়নামতি ক্যান্টনম্যান্ট জেনারেল হসপিটাল সেবায় অনন্য</td>
        </tr>

    </table>

</body>
</html><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/invoice/physio.blade.php ENDPATH**/ ?>