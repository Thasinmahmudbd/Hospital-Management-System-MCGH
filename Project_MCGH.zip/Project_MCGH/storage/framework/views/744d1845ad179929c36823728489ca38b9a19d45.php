

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','OT (Role Selection)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/ot/new/entry/all/data')); ?>" class="link">
        <i class="link_icons fas fa-th-list"></i>
        <span class="link_name"> Go To List </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/doctor_selection')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Surgeon </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/show/anesthesiologist/list')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Anesthesiologist </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/show/nurse/list')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Nurse </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/assistant/data/collection')); ?>" class="link">
        <i class="link_icons fas fa-user-plus"></i>
        <span class="link_name"> Pick Assistant </span>
    </a>
</li>

<li class="link_item">
    <a href="<?php echo e(url('/ot/new/entry/cancel')); ?>" class="link">
        <i class="link_icons far fa-window-close"></i>
        <span class="link_name"> Cancel Entry </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/ot/new/entry/all/data')); ?>">Go To List</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/doctor_selection')); ?>">Pick Surgeon</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/show/anesthesiologist/list')); ?>">Pick Anesthesiologist</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/show/nurse/list')); ?>">Pick Nurse</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/assistant/data/collection')); ?>">Pick Assistant</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/new/entry/cancel')); ?>">Cancel Entry</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>




                <!--Anesthesiologists info-->

                    <div class="content_container_bg_less_thin">

                        <span></span>
                            
                        <?php if(Session::get('list_data')=='anesthesiologist'): ?>
                        <p><b>Anesthesiologists:</b></p>
                        <?php elseif(Session::get('list_data')=='nurse'): ?>
                        <p><b>Nurses:</b></p>
                        <?php endif; ?>

                        <span></span>

                    </div>




                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="87%" class="frame_header_item">Name</th>
                        <th width="8%" class="frame_header_item">Remove</th>
                    </tr>

                    <?php if(Session::get('list_data')=='anesthesiologist'): ?>

                        <?php $serial = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="frame_rows">
                            <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                            <td class="frame_data" data-label="Name"><?php echo e($list->Dr_Name); ?></td>

                            <td class="frame_action" data-label="Action">
                                <a target="blank" href="<?php echo e(url('/ot/select/anesthesiologist/'.$list->D_ID)); ?>">
                                <i class="table_btn fas fa-check-circle"></i>
                                </a>
                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php elseif(Session::get('list_data')=='nurse'): ?>

                        <?php $serial = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="frame_rows">
                            <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                            <td class="frame_data" data-label="Name"><?php echo e($list->N_Name); ?></td>

                            <td class="frame_action" data-label="Action">
                                <a target="blank" href="<?php echo e(url('/ot/select/nurse/'.$list->N_ID)); ?>">
                                <i class="table_btn fas fa-check-circle"></i>
                                </a>
                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>

                </table>
                <div class="gap"></div>



<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/ot/list.blade.php ENDPATH**/ ?>