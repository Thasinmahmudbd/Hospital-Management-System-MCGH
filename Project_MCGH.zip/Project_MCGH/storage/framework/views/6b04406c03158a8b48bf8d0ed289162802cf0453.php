

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Confirm Invigilator'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/nurse/home/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patient List </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/nurse/doctor_selection')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> Reselect Invigilator</span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/nurse/home/')); ?>">Patient List</a>
</div>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/nurse/doctor_selection')); ?>">Reselect</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>





                    <!--confirm surgeon-->

                    <div class="patient_form_element_one_is_to_100px">

                        <div class="content_container_bg_less">
        
                            <p><b>You have selected <?php echo e(Session::get('D_NAME')); ?></b></p>

                        </div>

                        <div class="content_nav">
        
                            <a href="<?php echo e(url('/nurse/confirm/selection')); ?>" class="content_nav_link purple">Confirm</a>

                        </div>

                    </div>

                    <div class="purple_line"></div>
                    <div class="gap"></div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Patient Info</p>

                        <div class="info">

                            <p class="collected_info">Patients's Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('patient_name')); ?></p>

                        </div>

                    </div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Bed Info</p>

                        <div class="info">

                            <p class="collected_info">Bed No</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('bed_no')); ?></p>

                            <p class="collected_info">Floor No</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('floor_no')); ?></p>

                        </div>

                    </div>




<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/nurse/confirm.blade.php ENDPATH**/ ?>