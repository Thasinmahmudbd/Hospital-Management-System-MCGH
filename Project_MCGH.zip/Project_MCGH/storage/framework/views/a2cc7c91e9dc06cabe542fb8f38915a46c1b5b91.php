

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','OT (Scheduling Operations)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/ot/home/')); ?>" class="link">
        <i class="link_icons fas fa-window-maximize"></i>
        <span class="link_name"> Schedule </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/admission/list/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> New Entry </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/ot/invoice/generate/list/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Invoice </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/ot/home/')); ?>">Schedule</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/admission/list/')); ?>">New Entry</a>
    <a class="mobile_link" href="<?php echo e(url('/ot/invoice/generate/list/')); ?>">Invoice</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



                <!--Session message-->

                <?php if(session('msg')=='Provided P_ID is non existent.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

                <?php endif; ?>



                    <!--entry patients-->

                    <form action="<?php echo e(url('/ot/surgeon/selection')); ?>" class="content_container patient_info_form" method="post">
                    <?php echo csrf_field(); ?>

                        <div class="patient_form_element">

                            <label for="patient_id" class="label">Patient's ID</label>
                            <input type="text" class="input" name="patient_id" required>

                        </div>

                        <div class="patient_form_element_one_is_to_one">

                            <div class="patient_form_element_one_is_to_one">
                                
                                <div class="patient_form_element">

                                    <label for="otno" class="label">OT No</label>
                                    <input type="tel" class="input"  name="otno" required>

                                </div>

                                <div class="patient_form_element">

                                    <label for="operationDate" class="label">Operation Date</label>
                                    <input type="date" class="input"  name="operationDate" required>

                                </div>

                            </div>

                            <div class="patient_form_element_one_is_to_one">

                                <div class="patient_form_element">

                                    <label for="operationTime" class="label">Operation Time</label>
                                    <input type="time" class="input"  name="operationTime" required>

                                </div>

                                <div class="patient_form_element">

                                    <label for="operationDuration" class="label">Est.Operation Duration</label>
                                    <input type="text" class="input"  name="operationDuration" required>

                                </div>

                            </div>

                        </div>

                        <div class="patient_form_element">

                            <label for="operationType" class="label">Operation Type</label>
                            <input type="text" class="input"  name="operationType" required>

                        </div>

                        <div class="patient_form_element">

                            <input type="submit" class="btn patient_form_btn form_btn"  value="Select Surgeon" name="select_doctor">

                        </div>

                    </form>




<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/ot/schedule_entry.blade.php ENDPATH**/ ?>