

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Dental Service Payment'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/cancel_test/dental/')); ?>" class="link">
        <i class="link_icons fas fa-home"></i>
        <span class="link_name"> Go Home </span>
    </a>
</li>

<li class="link_item">
    <a href="<?php echo e(url('/reception/show_tests/dental/')); ?>" class="link">
        <i class="link_icons fas fa-plus-circle"></i>
        <span class="link_name"> Add More </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/cancel_test/dental/')); ?>">Go Home</a>
        <a class="mobile_link" href="<?php echo e(url('/reception/show_tests/dental/')); ?>">Add More</a>
    </div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



        <!--Session message-->

        <?php if(session('msg')=='Please assign an appointment time.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

        <?php elseif(session('msg')=='Appointment Canceled.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

        <?php endif; ?>











            <!--Patient info tab-->

            <form action="<?php echo e(url('/reception/submit/test/dental/')); ?>" method="post" class="content_container_white_super_thin center_self">
            <?php echo csrf_field(); ?>

            <div class="patient_and_doctor_info_one_is_to_one">

                <div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Patient Info</p>

                        <div class="info">

                            <p class="collected_info">Patient ID</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_P_ID')); ?></p>

                            <p class="collected_info">Patient's Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_NAME')); ?></p>

                            <p class="collected_info">Patient's Age</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_AGE')); ?></p>

                            <p class="collected_info">Patient's Gender</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_GENDER')); ?></p>

                        </div>

                    </div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Referred By</p>

                        <div class="info">

                            <p class="collected_info">Dentist</p>
                            <p>:</p>
                            <select name="dentist" class="input" required>
                                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list->D_ID); ?>"><?php echo e($list->Dr_Name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                    </div>

                </div>




                <div>

                    <!--consultant info-->

                    <div class="content_container_bg_less">

                        <!--<p class="section_title">Delivery</p>

                        <div class="info">

                            <p class="collected_info">Date</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input type="date" class="input" name="del_date" value="<?php echo e(Session::get('DATE_TODAY')); ?>">
                            </p>

                        </div>

                        <div class="gap"></div>-->

                        <p class="section_title">Billing Info</p>

                        <div class="info">

                            <p class="collected_info">Total Bill</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input type="tel" class="disNone" id="fee" value="<?php echo e(Session::get('Dentist_Test_Total_Fee')); ?>" readonly>
                                <input class="input disable shade" type="text" name="calculated_bill" value="<?php echo e(Session::get('Dentist_Test_Total_Fee')); ?>" id="estimate" required>
                            </p>

                            <p class="collected_info">Payment Status</p>
                            <p>:</p>
                            <p class="collected_info">
                                <select name="payment_status" class="input" required>
                                    <option value="Paid">Paid</option>
                                    <option value="Due">Due</option>
                                </select>
                            </p>

                            <p class="collected_info">Discount</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="discount" id="disc" oninput="calcDisc()" value="0" required>
                            </p>

                            <p class="collected_info">Received</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="received" oninput="calcAppointmentFee()" id="r2" value="0" required>
                            </p>

                            <p class="collected_info">Change</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="change" id="c2" value="0" required>
                            </p>

                            <p class="collected_info"></p>
                            <p></p>
                            <p class="collected_info">
                                <input type="submit" class="btn form_btn" name="confirm" value="Confirm">
                            </p>

                        </div>

                    </div>

                </div>

            </div>






                <!--Selected tests-->

                <div class="gap"></div>

                <!--Showing all of dental tests-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Selected Tests</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="50%" class="frame_header_item">Test Name</th>
                        <th width="20%" class="frame_header_item">Rate</th>
                        <th width="20%" class="frame_header_item">Fee</th>
                        <th width="5%" class="frame_header_item">Action</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="Test Name"><?php echo e($list->Test_Name); ?></td>
                        <td class="frame_data" data-label="Rate"><?php echo e($list->Rate); ?></td>

                            <td class="frame_data" data-label="Fee"><?php echo e($list->Fee); ?></td>

                            <td class="frame_action" data-label="Action">
                                <a href="<?php echo e(url('/reception/unselect/test/dental/'.$list->AI_ID)); ?>">
                                    <i class="table_btn_red fas fa-times-circle"></i>
                                </a>
                            </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>




            </form>









<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->


<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/dental_payment.blade.php ENDPATH**/ ?>