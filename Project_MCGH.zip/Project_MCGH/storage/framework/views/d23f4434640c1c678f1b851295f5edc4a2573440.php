

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Physio Payment'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/home/')); ?>" class="link">
        <i class="link_icons fas fa-home"></i>
        <span class="link_name"> Go Home </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

    <div id="myLinks" class="mobile_links">
        <a class="mobile_link" href="<?php echo e(url('/reception/cancel_test/dental/')); ?>">Go Home</a>
    </div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>



        <!--Session message-->

        <?php if(session('msg')=='Please assign an appointment time.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div> 

        <?php elseif(session('msg')=='Appointment Canceled.'): ?>

            <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

        <?php endif; ?>











            <!--Patient info tab-->

            <form action="<?php echo e(url('/reception/physio/entry/')); ?>" method="post" class="content_container_white_super_thin center_self">
            <?php echo csrf_field(); ?>

            <div class="patient_and_doctor_info_one_is_to_one">

                <div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Patient Info</p>

                        <div class="info">

                            <p class="collected_info">Patient ID</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_P_ID')); ?></p>

                            <p class="collected_info">Patient's Name</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_NAME')); ?></p>

                            <p class="collected_info">Patient's Age</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_AGE')); ?></p>

                            <p class="collected_info">Patient's Gender</p>
                            <p>:</p>
                            <p class="collected_info"><?php echo e(Session::get('PATIENT_GENDER')); ?></p>

                        </div>

                    </div>

                    <div class="content_container_bg_less">

                        <p class="section_title">Therapy By</p>

                        <div class="info">

                            <p class="collected_info">Therapist</p>
                            <p>:</p>
                            <select name="doctor" class="input" required>
                                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list->D_ID); ?>"><?php echo e($list->Dr_Name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                    </div>

                </div>




                <div>

                    <!--billing info-->

                    <div class="content_container_bg_less">

                        <p class="section_title">Billing Info</p>

                        <div class="info">

                            <p class="collected_info">Total Bill</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="calculated_bill" value="0" id="estimate" required>
                            </p>

                            <p class="collected_info">Received</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="received" oninput="calcAppointmentFee()" id="r2" value="0" required>
                            </p>

                            <p class="collected_info">Change</p>
                            <p>:</p>
                            <p class="collected_info">
                                <input class="input" type="text" name="change" id="c2" value="0" required>
                            </p>

                            <p class="collected_info"></p>
                            <p></p>
                            <p class="collected_info">
                                <input type="submit" class="btn form_btn" name="confirm" value="Confirm">
                            </p>

                        </div>

                    </div>

                </div>

            </div>

            </form>









<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->


<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/physio.blade.php ENDPATH**/ ?>