function copyPaste(form){
    form.per_village.value = form.pre_village.value;
    form.per_postOffice.value = form.pre_postOffice.value;
    form.per_upazilla.value = form.pre_upazilla.value;
    form.per_district.value = form.pre_district.value;
    }