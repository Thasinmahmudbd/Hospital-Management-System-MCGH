

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Nurse (Patient List)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="list_item">
    <a href="<?php echo e(url('/nurse/home/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patient List </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/nurse/home/')); ?>">Patient List</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>




                <div class="patient_and_doctor_info_one_is_to_one">

                    <!--Placeholder-->

                    <span></span>

                    <!--Search bar to search patients-->

                    <form action="<?php echo e(url('/nurse/find_patient/by_search/')); ?>" method="post" class="content_container_white_super_thin center_self">
                    <?php echo csrf_field(); ?>

                        <div class="patient_form_element_three_is_to_one">

                            <div class="patient_form_element_one_is_to_three">

                                <input type="text" class="input" name="floor_no" placeholder="Floor No">

                                <input type="text" class="input" name="old_patient_search_info" placeholder="Enter Patient full ID">

                            </div>

                            <button type="submit" class="btn form_btn" name="search_old_patient">Search</button>

                        </div>

                    </form>

                </div>



            <?php if(Session::get('INVOICE')=='1'): ?>

                <?php if(Session::get('SEARCH_RESULT')=='1'): ?>

                <div class="purple_line"></div>
                <div class="gap"></div>

                    <!--Session message-->

                    <?php if(session('msg')=='Records found.'): ?>

                    <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

                    <?php elseif(session('msg')=='Records not found.'): ?>

                    <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

                    <?php endif; ?>

                <!--Showing todays patients-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Search Result</b></p>

                    <span></span>

                </div>

                <table class="frame_table">

                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="20%" class="frame_header_item">P-ID</th>
                        <th width="20%" class="frame_header_item">Bed No</th>
                        <th width="20%" class="frame_header_item">Floor No</th>
                        <th width="17.25%" class="frame_header_item">Invigilator</th>
                        <th width="17.25%" class="frame_header_item">Others</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="P-ID"><?php echo e($list->P_ID); ?></td>
                        <td class="frame_data" data-label="Bed No"><?php echo e($list->Bed_No); ?></td>
                        <td class="frame_data" data-label="Floor No"><?php echo e($list->Floor_No); ?></td>

                        <td class="frame_action table_item_dark_green" data-label="Invigilator">
                            <a class="table_item_dark_green" href="<?php echo e(url('/choose/invigilator/'.$list->A_ID.'/invigilator')); ?>">
                                Select
                            </a>
                        </td>
                        
                        <td class="frame_action table_item_dark_green" data-label="Others">
                            <a class="table_item_dark_green" href="<?php echo e(url('/nurse/input/other/'.$list->A_ID.'/other')); ?>">
                                Input
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>



                <div class="gap"></div>

                <?php else: ?>

                <div class="purple_line"></div>
                <div class="gap"></div>

                <div class="warning_msg content_container_bg_less_thin">

                    <p class="text_center">No one here.</p>

                </div>

                <?php endif; ?>



            <?php elseif(Session::get('INVOICE')=='0'): ?>


                <div class="purple_line"></div>
                <div class="gap"></div>

                <!--Session message-->

                <?php if(session('msg')=='Invigilation recorded successfully.'): ?>

                <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

                <?php elseif(session('msg')=='Services recorded successfully.'): ?>

                <div class="content_container text_center success_msg"><?php echo e(session('msg')); ?></div>

                <?php elseif(session('msg')=='Fill up at-least one section.'): ?>

                <div class="content_container text_center warning_msg"><?php echo e(session('msg')); ?></div>

                <?php endif; ?>

                <!--Showing patients-->

                <div class="content_container_bg_less_thin">

                    <span></span>
                        
                    <p><b>Patients</b></p>

                    <span></span>

                </div>

                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="20%" class="frame_header_item">P-ID</th>
                        <th width="20%" class="frame_header_item">Bed No</th>
                        <th width="20%" class="frame_header_item">Floor No</th>
                        <th width="17.25%" class="frame_header_item">Invigilator</th>
                        <th width="17.25%" class="frame_header_item">Others</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="P-ID"><?php echo e($list->P_ID); ?></td>
                        <td class="frame_data" data-label="Bed No"><?php echo e($list->Bed_No); ?></td>
                        <td class="frame_data" data-label="Floor No"><?php echo e($list->Floor_No); ?></td>

                        <td class="frame_action table_item_dark_green" data-label="Invigilator">
                            <a class="table_item_dark_green" href="<?php echo e(url('/choose/invigilator/'.$list->A_ID.'/invigilator')); ?>">
                                Select
                            </a>
                        </td>
                        
                        <td class="frame_action table_item_dark_green" data-label="Others">
                            <a class="table_item_dark_green" href="<?php echo e(url('/nurse/input/other/'.$list->A_ID.'/other')); ?>">
                                Input
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            <?php endif; ?>





<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/nurse/home.blade.php ENDPATH**/ ?>