

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Reception (Patients List)'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/reception/home/')); ?>" class="link">
        <i class="link_icons fas fa-window-maximize"></i>
        <span class="link_name"> Patient Entry </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/emergency/')); ?>" class="link">
        <i class="link_icons fas fa-first-aid"></i>
        <span class="link_name"> Emergency </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/patient_list/')); ?>" class="link">
        <i class=" link_icons fas fa-th-list"></i>
        <span class="link_name"> Patients List </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Generate Invoice </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/reception/home/')); ?>">Patient Entry</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/emergency/')); ?>">Emergency</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/patient_list/')); ?>">Patients List</a>
    <a class="mobile_link" href="<?php echo e(url('/reception/invoice_list/appointment/')); ?>">Generate Invoice</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                <table class="frame_table">
                    
                    <tr class="frame_header">
                        <th width="5%" class="frame_header_item">S/N</th>
                        <th width="14%" class="frame_header_item">P-ID</th>
                        <th width="17%" class="frame_header_item">Patient Name</th>
                        <th width="14%" class="frame_header_item">Cell</th>
                        <th width="17%" class="frame_header_item">Doctor</th>
                        <th width="8%" class="frame_header_item">Fee</th>
                        <th width="5%" class="frame_header_item">Disc</th>
                        <th width="8%" class="frame_header_item">Total</th>
                        <th width="7%" class="frame_header_item">Status</th>
                        <th width="5%" class="frame_header_item">Action</th>
                    </tr>

                    <?php $serial = 1; ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="frame_rows">
                        <td class="frame_data" data-label="S/N"><?php echo $serial; $serial++; ?></td>
                        <td class="frame_data" data-label="P-ID"><?php echo e($list->P_ID); ?></td>
                        <td class="frame_data" data-label="Patient Name"><?php echo e($list->Patient_Name); ?></td>
                        <td class="frame_data" data-label="Cell"><?php echo e($list->Cell_Number); ?></td>
                        <td class="frame_data" data-label="Doctor"><?php echo e($list->Dr_Name); ?></td>
                        <td class="frame_data" data-label="Fee"><?php echo e($list->Basic_Fee); ?></td>
                        <td class="frame_data" data-label="Disc"><?php echo e($list->Discount); ?></td>
                        <td class="frame_data" data-label="Total"><?php echo e($list->Final_Fee); ?></td>
                        <td class="frame_data" data-label="Status"><?php echo e($list->Payment_Status); ?></td>

                        <?php if($list->Payment_Status == 'Unpaid'): ?>

                        <td class="frame_action" data-label="Action">
                            <a href="">
                                <i class="table_btn far fa-money-bill-alt"></i>
                            </a>
                        </td>

                        <?php else: ?>

                        <td class="frame_action" data-label="Action">
                            <a href=""  class="disable">
                                <i class="table_basic_btn far fa-money-bill-alt"></i>
                            </a>
                        </td>

                        <?php endif; ?>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->
<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/reception/patient_list.blade.php ENDPATH**/ ?>