

<?php $__env->startSection('page_title','MCGH Portal'); ?>

<?php $__env->startSection('page_type','Edit Profile'); ?>






<!-----------------------link---------------------->

<?php $__env->startSection('links'); ?>

<li class="link_item">
    <a href="<?php echo e(url('/accounts/home/')); ?>" class="link">
        <i class="link_icons fas fa-user-md"></i>
        <span class="link_name"> My Profile </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/doctor/income/')); ?>" class="link">
        <i class="link_icons fas fa-hand-holding-usd"></i>
        <span class="link_name"> Doctor's Income </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/cash/in/')); ?>" class="link">
        <i class="link_icons fas fa-cash-register"></i>
        <span class="link_name"> Cash In </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/pay/salary/')); ?>" class="link">
        <i class="link_icons fas fa-credit-card"></i>
        <span class="link_name"> Pay Salary </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/creditors/')); ?>" class="link">
        <i class="link_icons fas fa-search-dollar"></i>
        <span class="link_name"> Creditors </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/patient/release/')); ?>" class="link">
        <i class="link_icons fas fa-hospital-user"></i>
        <span class="link_name"> Patient Release </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/release/slips/')); ?>" class="link">
        <i class="link_icons fas fa-file-invoice"></i>
        <span class="link_name"> Release Slips </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/ambulance/')); ?>" class="link">
        <i class="link_icons fas fa-ambulance"></i>
        <span class="link_name"> Ambulance </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/other/transactions/')); ?>" class="link">
        <i class="link_icons fas fa-random"></i>
        <span class="link_name"> Other Transactions </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/log/')); ?>" class="link">
        <i class="link_icons fas fa-clipboard-list"></i>
        <span class="link_name"> Logs </span>
    </a>
</li>

<li class="list_item">
    <a href="<?php echo e(url('/accounts/edit_profile/')); ?>" class="link">
        <i class="link_icons fas fa-user-edit"></i>
        <span class="link_name"> Edit Profile </span>
    </a>
</li>

<?php $__env->stopSection(); ?>

<!--------------------link end---------------------->






<!-----------------------mobile link---------------------->

<?php $__env->startSection('mobile_links'); ?>

<div id="myLinks" class="mobile_links">
    <a class="mobile_link" href="<?php echo e(url('/accounts/home/')); ?>">My Profile</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/doctor/income/')); ?>">Doctors Income</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/cash/in/')); ?>">Cash In</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/pay/salary/')); ?>">Pay Salary</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/creditors/')); ?>">Creditors</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/patient/release/')); ?>">Patient Release</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/release/slips/')); ?>">Release Slips</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/ambulance/')); ?>">Ambulance</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/other/transactions/')); ?>">Other Transactions</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/log/')); ?>">Logs</a>
    <a class="mobile_link" href="<?php echo e(url('/accounts/edit_profile/')); ?>">Edit Profile</a>
</div>

<?php $__env->stopSection(); ?>

<!--------------------mobile link end---------------------->







<!-----------------------content---------------------->

<?php $__env->startSection('content'); ?>

                    <form action="<?php echo e(url('/accounts/save_edit/')); ?>" method="post" enctype="multipart/form-data" class="rounded_photo_width_is_to_rest">
                    <?php echo csrf_field(); ?>

                        <div class="content_container center_element">

                        <?php if(Session::get('ACCOUNTANTS_IMAGE')): ?>

                            <img src="<?php echo e(asset('storage/account_profile_pictures/'.Session::get('ACCOUNTANTS_IMAGE'))); ?>" alt="Upload Photo" class="placeholder_image" width="100%" onclick="triggerClick()">

			                <input class="input img_uploader" type="file" name="profile_photo" onchange="displayImage(this)" id="place_holder">
                        
                        <?php elseif(Session::get('ACCOUNTANTS_GENDER')=='male' || Session::get('ACCOUNTANTS_GENDER')=='Male'): ?>

                            <img src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-male.png')); ?>" alt="Upload Photo" class="placeholder_image" width="100%" onclick="triggerClick()">

			                <input class="input img_uploader" type="file" name="profile_photo" onchange="displayImage(this)" id="place_holder">

                        <?php elseif(Session::get('ACCOUNTANTS_GENDER')=='female' || Session::get('ACCOUNTANTS_GENDER')=='Female'): ?>

                            <img src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/default-placeholder-doctor-half-length-portrait-vector-female.png')); ?>" alt="Upload Photo" class="placeholder_image" width="100%" onclick="triggerClick()">

			                <input class="input img_uploader" type="file" name="profile_photo" onchange="displayImage(this)" id="place_holder">

                        <?php else: ?>

                            <img src="<?php echo e(url('/UI_Assets/Media/Images/Template_Images/system/Profile_avatar_placeholder_large.png')); ?>" alt="Upload Photo" class="placeholder_image" width="100%" onclick="triggerClick()">

                            <input class="input img_uploader" type="file" name="profile_photo" onchange="displayImage(this)" id="place_holder">

                        <?php endif; ?>

                        </div>





                        <div class="span_hidden_bar">

                            <div class="info content_container_bg_less">

                                <p class="collected_info">Name</p>
                                <p class="collected_info">:</p>
                                <input type="text" value="<?php echo e(Session::get('ACCOUNTANTS_NAME')); ?>" name="acc_name" class="collected_info input">

                                <p class="collected_info">Email</p>
                                <p class="collected_info">:</p>
                                <input type="text" value="<?php echo e(Session::get('ACCOUNTANTS_EMAIL')); ?>" name="acc_email" class="collected_info input">

                                <p class="collected_info">Phone</p>
                                <p class="collected_info">:</p>
                                <input type="tel" value="<?php echo e(Session::get('ACCOUNTANTS_PHONE')); ?>" name="acc_phone" class="collected_info input">

                            </div>

                            <button type="submit" class="cancel_btn_style purple_icon">
                                <i class="fas fa-check-circle log_out_btn purple_icon"></i>
                            </button>

                        </div>

                    </form>

                    <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="content_container_bg_less_thin text_center warning_msg"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>























<?php $__env->stopSection(); ?>

<!--------------------content end---------------------->

<?php echo $__env->make('hospital/frame/frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\Project_MCGH\resources\views/hospital/accounts/edit_profile.blade.php ENDPATH**/ ?>